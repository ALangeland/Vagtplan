<?php
/* Opdaterer Vagtløn på et almindeligt webhotel (fx Simply.com) fra pakken på GitHub (grenen «live»).
 *
 *   php opdater.php --web=/sti/til/websitets/rod            opdater nu
 *   php opdater.php --web=/sti/til/websitets/rod --auto     kør stille; gør kun noget, hvis der er en ny version (til cron)
 *
 * Rører aldrig api/config.php eller databasen. Før hver opdatering tages en sikkerhedskopi af databasen, og den forrige
 * version gemmes. Svarer siden ikke bagefter, rulles den tilbage automatisk. Filen ligger UDEN FOR websitets mappe.
 */
declare(strict_types=1);
error_reporting(E_ALL); ini_set('display_errors', '1');
$o = getopt('', ['web:', 'auto', 'base::', 'state::']);
$web = rtrim((string)($o['web'] ?? ''), '/'); $auto = isset($o['auto']);
$base = rtrim((string)($o['base'] ?? 'https://raw.githubusercontent.com/ALangeland/Vagtplan/live'), '/');
if ($web === '' || !is_dir($web)) { fwrite(STDERR, "Brug: php opdater.php --web=/sti/til/websitets/rod [--auto]\n"); exit(2); }
$state = rtrim((string)($o['state'] ?? dirname($web) . '/.vagtlon-opdater'), '/');
@mkdir($state, 0700, true); if (!is_writable($state)) { fwrite(STDERR, "Kan ikke skrive til $state\n"); exit(2); }
function lg(string $m): void { echo date('Y-m-d H:i:s') . " $m\n"; }
function get(string $url, int $t = 60): ?string {
    if (function_exists('curl_init')) { $c = curl_init($url); curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => $t, CURLOPT_USERAGENT => 'vagtlon-opdater']); $r = curl_exec($c); $code = curl_getinfo($c, CURLINFO_RESPONSE_CODE); curl_close($c); return ($r !== false && $code === 200) ? (string)$r : null; }
    $r = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => $t, 'follow_location' => 1, 'user_agent' => 'vagtlon-opdater']])); return $r === false ? null : $r;
}
function rrm(string $d): void { if (!is_dir($d)) return; foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $f) $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); @rmdir($d); }
function listFiles(string $d): array { $o = []; if (!is_dir($d)) return $o; foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS)) as $f) if ($f->isFile()) $o[] = substr($f->getPathname(), strlen($d) + 1); sort($o); return $o; }
function keep(string $rel): bool { return $rel === 'api/config.php' || str_starts_with($rel, 'api/data/'); }   // dem rører vi aldrig

$lock = fopen("$state/lock", 'c'); if (!flock($lock, LOCK_EX | LOCK_NB)) { lg('opdatering kører allerede'); exit(0); }
$ver = get("$base/VERSION", 30);
if ($ver === null) { if (!$auto) lg("Kunne ikke hente $base/VERSION"); exit($auto ? 0 : 1); }
$lines = preg_split('/\R/', trim($ver)); $new = trim($lines[0] ?? ''); $sha = trim($lines[1] ?? '');
$cur = is_file("$state/installed") ? trim((string)file_get_contents("$state/installed")) : '';
if ($auto && $new === $cur) exit(0);
if ($auto && is_file("$state/failed") && trim((string)file_get_contents("$state/failed")) === $new) exit(0);   // prøv ikke den samme dårlige version igen og igen
if ($new === '' || !preg_match('/^[a-f0-9]{64}$/', $sha)) { lg('VERSION-filen ser forkert ud. Afbryder.'); exit(1); }
$zip = get("$base/vagtplan-php-pakke.zip", 180);
if ($zip === null) { lg('Kunne ikke hente pakken.'); exit(1); }
if (!hash_equals($sha, hash('sha256', $zip))) { lg('Pakkens kontrolsum passer ikke. Afbryder.'); exit(1); }
$tmp = "$state/ny"; rrm($tmp); mkdir($tmp, 0700, true); file_put_contents("$tmp/p.zip", $zip);
$z = new ZipArchive(); if ($z->open("$tmp/p.zip") !== true) { lg('Pakken kunne ikke åbnes.'); exit(1); }
$z->extractTo("$tmp/p"); $z->close();
$src = "$tmp/p/webroot";
if (!is_file("$src/app.html") || !is_file("$src/api/index.php")) { lg('Pakken ser forkert ud. Afbryder.'); exit(1); }

/* 1. sikkerhedskopi af databasen og den nuværende version */
if (is_file("$web/api/config.php")) { $out = []; exec(escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg("$web/api/index.php") . ' backup 2>&1', $out); }
$prev = "$state/forrige"; rrm($prev); mkdir($prev, 0700, true);
foreach (listFiles($web) as $rel) { if (keep($rel)) continue; @mkdir(dirname("$prev/$rel"), 0700, true); copy("$web/$rel", "$prev/$rel"); }
/* 2. læg den nye version ind og fjern filer, der ikke findes mere */
$old = is_file("$state/files.txt") ? array_filter(explode("\n", (string)file_get_contents("$state/files.txt"))) : [];
$newList = listFiles($src);
foreach ($newList as $rel) { if (keep($rel)) continue; @mkdir(dirname("$web/$rel"), 0755, true); copy("$src/$rel", "$web/$rel.nyt") && rename("$web/$rel.nyt", "$web/$rel"); }
foreach ($old as $rel) if (!in_array($rel, $newList, true) && !keep($rel)) @unlink("$web/$rel");
/* 3. sundhedstjek: koden skal kunne læses, og siden skal svare med gyldig JSON */
function healthy(string $web): bool {
    $cfgF = "$web/api/config.php"; if (!is_file($cfgF)) return true;   // ikke sat op endnu
    $cfg = require $cfgF; $url = rtrim((string)($cfg['base_url'] ?? ''), '/') . '/api/?a=me';
    for ($i = 0; $i < 4; $i++) { $r = get($url, 20); $j = $r !== null ? json_decode($r, true) : null; if (is_array($j) && array_key_exists('user', $j)) return true; sleep(3); }
    return false;
}
$lint = []; exec(escapeshellarg(PHP_BINARY) . ' -l ' . escapeshellarg("$web/api/index.php") . ' 2>&1', $lint, $rc);
if ($rc === 0 && healthy($web)) {
    file_put_contents("$state/installed", $new); file_put_contents("$state/files.txt", implode("\n", $newList)); @unlink("$state/failed");
    $self = "$tmp/p/webhotel/opdater.php"; if (is_file($self) && ($s = file_get_contents($self)) && str_contains($s, '<?php')) { file_put_contents(__FILE__ . '.nyt', $s) && rename(__FILE__ . '.nyt', __FILE__); }
    rrm($tmp); lg("Opdateret til version $new."); exit(0);
}
lg('Sundhedstjekket fejlede. Ruller tilbage til den forrige version.'); file_put_contents("$state/failed", $new);
foreach (listFiles($prev) as $rel) copy("$prev/$rel", "$web/$rel");
foreach ($newList as $rel) if (!keep($rel) && !is_file("$prev/$rel")) @unlink("$web/$rel");
rrm($tmp); exit(1);
