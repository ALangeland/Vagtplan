# Drift af Vagtløn-serveren

Alle kommandoer køres på serveren (Hetzners *Console* eller SSH). Skriv `vagtplan` uden noget efter for en oversigt.

## Hverdag
| Kommando | Hvad den gør |
|---|---|
| `vagtplan status` | Viser om serveren kører, hvor meget plads der er, og de seneste backups |
| `vagtplan brugere` | Viser alle konti og om de er bekræftet |
| `vagtplan bekraeft bruger@mail.dk` | Bekræfter en konto manuelt |
| `vagtplan adgangskode bruger@mail.dk` | Giver en midlertidig adgangskode |
| `vagtplan log` | Følger serverens log. Afslut med Ctrl+C |
| `vagtplan genstart` | Genstarter efter en ændring i `/opt/vagtplan/.env` |
| `vagtplan opdater` | Henter og installerer den nyeste version af Vagtløn |

Administrationssiden `/admin.html` viser brugere, besøg, overenskomster, afdelinger og henvendelser fra brugerne.

## Opdatering (sker af sig selv)
Serveren tjekker hvert 10. minut, om der er udgivet en ny version på GitHub (grenen `live`). Der udgives kun, når du har sagt «go». Så sker der dette, uden at du skal gøre noget:
1. Serveren henter pakken og tjekker kontrolsummen.
2. Den tager en sikkerhedskopi af databasen og gemmer den forrige version.
3. Den lægger den nye version ind og tester, at databasen kan åbnes, og at siden svarer.
4. Svarer den ikke, ruller den selv tilbage til den forrige version og prøver ikke den samme udgave igen. Du kan se det i loggen (`/var/log/vagtplan-update.log`).

Dine indstillinger (`.env`) og data (`appdata/`) røres ikke. Vil du opdatere med det samme: `vagtplan opdater`. Vil du stoppe automatikken: fjern linjen med `opdater.sh --auto` i `/etc/cron.d/vagtplan`.

Vigtigt: Den, der kan skrive til GitHub-kontoen, kan ændre koden på din server. Slå tofaktorlogin til på GitHub.

## Sikkerhedskopi og gendannelse
- Hver nat kl. 03.15 laves en komprimeret kopi af databasen i `/opt/vagtplan/appdata/backups/`. De seneste 14 gemmes.
- Kopierne ligger på selve serveren. Hent jævnligt en til din egen computer, eller slå Hetzners backups til (20 % oven i serverprisen). Så overlever du også, hvis serveren selv går tabt.
- **Gendan:**
  ```
  cd /opt/vagtplan
  docker compose stop
  gunzip -c appdata/backups/app-ÅÅÅÅMMDD-TTMMSS.sqlite.gz > appdata/app.sqlite
  rm -f appdata/app.sqlite-wal appdata/app.sqlite-shm
  docker compose start
  ```

## Vokser du?
- Serveren kan opgraderes i Hetzners konsol (*Rescale*). Det giver mere kraft på få minutter. Databasen er kun én fil, og hver bruger fylder én række, så de første mange tusinde brugere kan ligge på samme server.
- Mailtjenesten Brevo er gratis op til 300 mails om dagen. Over det koster den fra ca. 9 $ om måneden.
- Mærker du, at mange skriver samtidigt (flere hundrede ad gangen), er næste skridt at flytte databasen fra SQLite til PostgreSQL. Det er en afgrænset ændring i `api/index.php`.

## Hvad serveren gemmer
- Konti: e-mail og adgangskode (kun som sikker hash).
- Hver brugers samlede data som én post. Administratoren ser kun e-mail og tal.
- Delte normperioder og vagtformer: anonymt, uden kobling til en bruger. De fjernes, når den sidste der delte dem, sletter sin konto.
- Besøgstal pr. dag uden cookies og uden IP-adresser.
- Brugere kan selv hente alle deres data og slette deres konto i appen.

## Sikkerhed
- Port 22 (SSH), 80 og 443 er åbne. Resten er lukket (ufw), og fail2ban blokerer gentagne loginforsøg på SSH.
- Ubuntu installerer sikkerhedsopdateringer automatisk. Kør af og til `apt update && apt upgrade -y` og genstart serveren.
- `/opt/vagtplan/.env` indeholder dine mail-oplysninger. Del den aldrig.
