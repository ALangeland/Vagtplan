# Vagtløn – kom i gang med beta

Pakken indeholder alt til at køre Vagtløn med login, synkronisering mellem enheder, kalenderabonnement, deling mellem kolleger og administration. Den bruger kun PHP og en lille databasefil (SQLite). Der er ingen Firebase i den.

Der er to veje. De bruger **den samme pakke**, så du kan starte på den ene og flytte til den anden senere.

| | A. Webhotel hos Simply.com (start her) | B. Egen server hos Hetzner (når du vokser) |
|---|---|---|
| Pris | ca. 5 kr./md. første år, derefter ca. 70 kr./md. | ca. 55–65 kr./md. |
| Din indsats første gang | ca. 30 minutter | ca. 30 minutter |
| Kraft | Delt med andre websteder | Egen virtuel server |
| Mappe i pakken | `webroot/` og `webhotel/` | `server/` og `cloud-init.yaml` |

---

## A. Webhotel hos Simply.com

Domænerne er vagtloen.dk (hovedadresse) og vagtløn.dk (sender videre).

### Trin 1. Tjek og slå funktioner til i Simplys kontrolpanel
Menupunkterne hedder lidt forskelligt, så kig i Simplys hjælp, hvis du ikke kan finde dem.
1. **PHP-version:** Vælg PHP 8.3 eller nyere til websitet (mindst 8.1).
2. **HTTPS / SSL-certifikat:** Slå et gratis certifikat til for vagtloen.dk, så adressen starter med `https://`.
3. **Cronjobs** (og eventuelt **SSH**): Cronjobs bruges til automatiske opdateringer og sikkerhedskopi (trin 6). SSH er kun en bekvem ekstra til administration. Uden cron kan du stadig køre appen, men så uploader du nye versioner selv.
4. **Postkasse:** Opret en postkasse `noreply@vagtloen.dk`. Appen sender bekræftelsesmails og nulstilling af adgangskode fra den. Noter adgangskoden til postkassen. Den skal du bruge i trin 3.

### Trin 2. Upload filerne
1. Pak `vagtplan-php-pakke.zip` ud på din computer.
2. Upload **alt indhold i mappen `webroot/`** til websitets rodmappe hos Simply (via FTP/SFTP eller filhåndteringen). Husk skjulte filer som `.htaccess`.
3. Åbn `https://vagtloen.dk/api/`. Du skal se en besked om, at serveren ikke er sat op endnu. Så virker PHP.

### Trin 3. Sæt indstillingerne
1. I mappen `api/` på webhotellet: kopiér `config.sample.php` til `config.php`.
2. Ret værdierne:
   - `base_url`: `https://vagtloen.dk`
   - `mail_from`: `noreply@vagtloen.dk`
   - `admin_emails`: din e-mail. Kontoen med den e-mail får adgang til `/admin.html`.
   - `smtp_host`, `smtp_port`, `smtp_secure`, `smtp_user`, `smtp_pass`: fjern `//` foran og udfyld med oplysningerne til din postkasse (se Simplys hjælp om mailopsætning, SMTP/udgående server). Brugernavn er typisk hele mailadressen. Port 587 med `tls`, eller port 465 med `ssl`.
   - `data_dir`: en mappe **uden for websitets rodmappe**, som PHP kan skrive til. Opret den ved siden af websitets mappe. Det er her databasen ligger.
   - `controller` og `contact_email`: dit navn og adresse (som dataansvarlig) og en kontakt-e-mail. Vises offentligt på `/privatliv.html`.
3. Åbn `https://vagtloen.dk`, opret en konto med din admin-e-mail, tryk på linket i bekræftelsesmailen (tjek spam), log ind, og åbn `https://vagtloen.dk/admin.html`.

### Trin 4. Send vagtløn.dk videre til vagtloen.dk (DNS-domænet)
Sæt en omdirigering op i Simplys kontrolpanel (vagtløn.dk er et rent DNS-domæne uden webhotel; vagtloen.dk er selve webhotellet. Sæt videresendelse op under vagtløn.dk → videresend til `https://vagtloen.dk`).

### Trin 5. Test, før du inviterer andre
- Opret en konto nummer to med en anden e-mail, og tjek at mailen kommer frem og ikke havner i spam.
- Slå kalenderabonnement til under *Opsætning* og tilføj det i din kalender.
- Del en vagtform fra den ene konto, og hent den på den anden.
- Læg appen på telefonens hjemmeskærm.

### Trin 6 (anbefalet). Automatiske opdateringer og sikkerhedskopi via cronjob (uden SSH)
Simplys «Cronjobs» i kontrolpanelet kalder en webadresse med faste mellemrum. Det er nok til både sikkerhedskopi og automatisk opdatering.
1. Find på [random.org](https://www.random.org/strings/) eller i en adgangskodeadministrator en tilfældig nøgle på mindst 20 tegn (kun bogstaver og tal). Skriv den i `api/config.php`: `'cron_key' => 'din-nøgle',` (fjern `//` foran linjen).
2. Test i browseren (erstat NØGLE): `https://vagtloen.dk/api/cron.php?k=NØGLE&a=backup`. Der skal stå «Sikkerhedskopi: …». Står der «Ikke fundet», er nøglen forkert eller ikke gemt.
3. I kontrolpanelet: Cronjobs → Opret nyt cronjob. Opret to:
   - **Sikkerhedskopi:** URL `https://vagtloen.dk/api/cron.php?k=NØGLE&a=backup`, minut `15`, time `3`, resten `*` (hver nat kl. 03.15).
   - **Opdatering:** URL `https://vagtloen.dk/api/cron.php?k=NØGLE&a=update`, minut `*/10`, resten `*` (hvert 10. minut).
   Brug præcis den endelige https-adresse uden omdirigering (ingen `www`, hvis den sendes videre).
4. Kontrollér efter en time: `data/updater/opdatering.log` i din `data_dir` viser, hvad der er sket.
Når der er udgivet en ny version, henter webhotellet den inden for 10 minutter. Før hver opdatering tages en sikkerhedskopi af databasen, og går noget galt, ruller den selv tilbage. Din `config.php` og databasen røres ikke.

**Alternativ med SSH:** `webhotel/opdater.php` gør det samme fra en crontab (`*/10 * * * * php /sti/opdater.php --web=/sti/til/rod --auto` og `15 3 * * * php /sti/til/rod/api/index.php backup`). Brug enten URL-cron eller SSH-cron, ikke begge.

### Administration fra SSH
Fra websitets rodmappe:
```
php api/index.php users                      vis alle konti
php api/index.php verify bruger@mail.dk      bekræft en konto manuelt
php api/index.php passwd bruger@mail.dk      lav en midlertidig adgangskode
php api/index.php backup                     tag en sikkerhedskopi nu
```
Sikkerhedskopierne ligger i `backups/` i `data_dir`. Hent jævnligt en til din egen computer.

### Hvis noget går galt
| Problem | Løsning |
|---|---|
| Hvid side eller fejl på `/api/` | Tjek PHP-versionen (trin 1). Er `config.php` ret rigtigt? Tjek Simplys fejllog |
| Bekræftelsesmailen kommer ikke | Tjek spam og SMTP-oplysningerne. Bekræft kontoen manuelt i `/admin.html` eller med `verify` |
| «Databasen kunne ikke åbnes» | Mappen i `data_dir` findes ikke eller kan ikke skrives til |
| Siden er langsom med mange brugere | Delt hosting har grænser. Flyt til vej B (se nedenfor) |

---

## B. Egen server hos Hetzner

Brug denne vej, når webhotellet bliver for langsomt, eller du vil have mere kontrol.

1. **Opret server** hos [Hetzner Cloud](https://www.hetzner.com/cloud): Ubuntu 24.04, den billigste delte x86-model (CX23), placering Falkenstein, Nürnberg eller Helsinki, Public IPv4 slået til, gerne backups. Indsæt indholdet af `cloud-init.yaml` i feltet *Cloud config*, efter du har rettet de linjer, der er markeret `<<< RET` (adresse, admin-e-mail, mailoplysninger).
2. **Peg domænet** på serverens IPv4-adresse: opret en A-record for vagtloen.dk hos Simply (eller den, der styrer dit domæne).
3. Efter ca. 4 minutter svarer `https://vagtloen.dk`. Serveren henter selv certifikat, opdaterer sig selv hver 10. minut og tager sikkerhedskopi hver nat. Se `DRIFT.md`.

### Flyt fra webhotel til server
1. Tag en sikkerhedskopi på webhotellet (`php api/index.php backup`) og hent filen fra `backups/`.
2. Læg den på serveren som `/opt/vagtplan/appdata/app.sqlite` (stop serveren først med `vagtplan genstart` efter kopiering).
3. Peg domænet på serveren. Brugerne skal ikke gøre noget. Kalenderabonnementer og login følger med, fordi adressen er den samme.

---

## Før du åbner for andre
1. **Privatlivssiden:** `controller` og `contact_email` udfyldt (trin 3).
2. **Databehandleraftale** med din hostingudbyder (Simply eller Hetzner). Accepter den i kontrolpanelet.
3. **Overenskomsterne:** Appen viser en status for hver (Afstemt, Gennemgået eller Grundmodel). Fortæl testerne, at tallene er vejledende, og at de skal tjekke mod lønsedlen.
4. **Backup:** Hent en kopi af databasen til din egen computer med jævne mellemrum.
