<?php
/* Kaldes af webhotellets cronjob (URL-cron) med en hemmelig nøgle. Kræver ikke SSH.
 *   https://DIT-DOMÆNE/api/cron.php?k=NØGLEN&a=backup     tag en sikkerhedskopi af databasen (kør 1 gang i døgnet)
 *   https://DIT-DOMÆNE/api/cron.php?k=NØGLEN&a=update     hent og installer ny udgivet version (kør hvert 10. minut)
 * Nøglen står som 'cron_key' i config.php (mindst 20 tegn). Uden nøgle er filen slukket. */
declare(strict_types=1);
header('Content-Type: text/plain; charset=utf-8'); header('Cache-Control: no-store');
$cfgFile = __DIR__ . '/config.php';
if (!is_file($cfgFile)) { http_response_code(503); exit("config.php mangler\n"); }
$cfg = require $cfgFile; $key = (string)($cfg['cron_key'] ?? '');
if (strlen($key) < 20 || !hash_equals($key, (string)($_GET['k'] ?? ''))) { http_response_code(404); exit("Ikke fundet\n"); }
@ignore_user_abort(true); @set_time_limit(180);
$a = (string)($_GET['a'] ?? '');
if ($a === 'backup') { define('VP_CRON', 1); $argv = ['cron', 'backup']; require __DIR__ . '/index.php'; exit; }
if ($a !== 'update') { http_response_code(400); exit("Brug a=backup eller a=update\n"); }

$web = dirname(__DIR__); $auto = true;
$base = rtrim((string)($cfg['update_base'] ?? 'https://raw.githubusercontent.com/ALangeland/Vagtplan/live'), '/');
$state = rtrim((string)($cfg['data_dir'] ?? (__DIR__ . '/data')), '/') . '/updater';
@mkdir($state, 0700, true); if (!is_writable($state)) { http_response_code(500); exit("Kan ikke skrive til $state\n"); }
function lg(string $m): void { $l = date('Y-m-d H:i:s') . " $m\n"; echo $l; global $state; @file_put_contents("$state/opdatering.log", $l, FILE_APPEND); }
function get(string $url, int $t = 60): ?string {
    if (function_exists('curl_init')) { $c = curl_init($url); curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => $t, CURLOPT_USERAGENT => 'vagtlon-opdater']); $r = curl_exec($c); $code = curl_getinfo($c, CURLINFO_RESPONSE_CODE); curl_close($c); return ($r !== false && $code === 200) ? (string)$r : null; }
    $r = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => $t, 'follow_location' => 1, 'user_agent' => 'vagtlon-opdater']])); return $r === false ? null : $r;
}
function rrm(string $d): void { if (!is_dir($d)) return; foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $f) $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname()); @rmdir($d); }
function listFiles(string $d): array { $o = []; if (!is_dir($d)) return $o; foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS)) as $f) if ($f->isFile()) $o[] = substr($f->getPathname(), strlen($d) + 1); sort($o); return $o; }
function keep(string $rel): bool { return $rel === 'api/config.php' || str_starts_with($rel, 'api/data/'); }

$lock = fopen("$state/lock", 'c'); if (!flock($lock, LOCK_EX | LOCK_NB)) { echo "opdatering kører allerede\n"; exit; }
$ver = get("$base/VERSION", 30);
if ($ver === null) { echo "Kunne ikke hente VERSION (ingen udgivelse endnu?)\n"; exit; }
$lines = preg_split('/\R/', trim($ver)); $new = trim($lines[0] ?? ''); $sha = trim($lines[1] ?? '');
$cur = is_file("$state/installed") ? trim((string)file_get_contents("$state/installed")) : '';
if ($new === $cur) { echo "Ajour ($cur)\n"; exit; }
if (is_file("$state/failed") && trim((string)file_get_contents("$state/failed")) === $new) { echo "Version $new fejlede tidligere og prøves ikke igen\n"; exit; }
if ($new === '' || !preg_match('/^[a-f0-9]{64}$/', $sha)) { lg('VERSION-filen ser forkert ud. Afbryder.'); exit; }
$zip = get("$base/vagtplan-php-pakke.zip", 120);
if ($zip === null) { lg('Kunne ikke hente pakken.'); exit; }
if (!hash_equals($sha, hash('sha256', $zip))) { lg('Pakkens kontrolsum passer ikke. Afbryder.'); exit; }
if (!class_exists('ZipArchive')) { lg('Serveren mangler ZipArchive.'); exit; }
$tmp = "$state/ny"; rrm($tmp); mkdir($tmp, 0700, true); file_put_contents("$tmp/p.zip", $zip);
$z = new ZipArchive(); if ($z->open("$tmp/p.zip") !== true) { lg('Pakken kunne ikke åbnes.'); exit; }
$z->extractTo("$tmp/p"); $z->close(); $src = "$tmp/p/webroot";
if (!is_file("$src/app.html") || !is_file("$src/api/index.php") || !is_file("$src/api/cron.php")) { lg('Pakken ser forkert ud. Afbryder.'); exit; }
/* sikkerhedskopi: databasen (via backup-kaldet) og den nuværende version */
$self = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['SCRIPT_NAME'] ?? '') . '?k=' . rawurlencode($key) . '&a=backup';
@get($self, 60);
$prev = "$state/forrige"; rrm($prev); mkdir($prev, 0700, true);
foreach (listFiles($web) as $rel) { if (keep($rel) || str_starts_with($rel, 'api/data/')) continue; @mkdir(dirname("$prev/$rel"), 0700, true); @copy("$web/$rel", "$prev/$rel"); }
$old = is_file("$state/files.txt") ? array_filter(explode("\n", (string)file_get_contents("$state/files.txt"))) : [];
$newList = listFiles($src);
foreach ($newList as $rel) { if (keep($rel)) continue; @mkdir(dirname("$web/$rel"), 0755, true); if (@copy("$src/$rel", "$web/$rel.nyt")) rename("$web/$rel.nyt", "$web/$rel"); }
foreach ($old as $rel) if (!in_array($rel, $newList, true) && !keep($rel)) @unlink("$web/$rel");
/* sundhedstjek: den nye kode skal svare med gyldig JSON */
$ok = false; $url = rtrim((string)($cfg['base_url'] ?? ''), '/') . '/api/?a=me';
sleep(3); // opcache på webhotellet kan i et par sekunder vise gammel kode
for ($i = 0; $i < 4 && !$ok; $i++) { if ($i) sleep(3); $r = get($url, 20); $j = $r !== null ? json_decode($r, true) : null; $ok = is_array($j) && array_key_exists('user', $j); }
if ($ok) { file_put_contents("$state/installed", $new); file_put_contents("$state/files.txt", implode("\n", $newList)); @unlink("$state/failed"); rrm($tmp); lg("Opdateret til version $new."); exit; }
lg('Sundhedstjekket fejlede. Ruller tilbage til den forrige version.'); file_put_contents("$state/failed", $new);
foreach (listFiles($prev) as $rel) @copy("$prev/$rel", "$web/$rel");
foreach ($newList as $rel) if (!keep($rel) && !is_file("$prev/$rel")) @unlink("$web/$rel");
rrm($tmp);
