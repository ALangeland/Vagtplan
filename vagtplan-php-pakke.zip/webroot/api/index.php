<?php
declare(strict_types=1);
/* Vagtløn API – PHP 8 + SQLite. Ingen afhængigheder. */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

date_default_timezone_set('Europe/Copenhagen');
ini_set('display_errors', '0');
set_exception_handler(function (Throwable $e) {
    error_log('Vagtløn: ' . $e);
    if (!headers_sent()) { http_response_code(PHP_SAPI === 'cli' ? 200 : 500); header('Content-Type: application/json; charset=utf-8'); }
    echo PHP_SAPI === 'cli' ? 'Fejl: ' . $e->getMessage() . "\n" : json_encode(['error' => 'Serveren havde et øjebliksproblem. Prøv igen om lidt.'], JSON_UNESCAPED_UNICODE);
    exit(PHP_SAPI === 'cli' ? 1 : 0);
});
/* Hent ét resultat og luk markøren med det samme. Et åbent SELECT holder en læse-transaktion åben i SQLite,
   og så fejler den efterfølgende skrivning med «database is locked», hvis en anden bruger har gemt imens. */
function fc(PDOStatement $q) { $v = $q->fetchColumn(); $q->closeCursor(); return $v; }
function fr(PDOStatement $q) { $v = $q->fetch(PDO::FETCH_ASSOC); $q->closeCursor(); return $v; }
function out($d, int $code = 200): never { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function fail(string $m, int $code = 400): never { out(['error' => $m], $code); }

/* Indstillinger: enten api/config.php (webhotel) eller miljøvariabler (Docker/VPS, se deploy/). */
function envCfg(): ?array {
    $g = fn(string $k, ?string $d = null): ?string => (($v = getenv($k)) === false || $v === '') ? $d : $v;
    $base = $g('VP_BASE_URL'); if ($base === null) return null;
    $bool = fn(?string $v, bool $d): bool => $v === null ? $d : !in_array(strtolower($v), ['0', 'false', 'nej', 'no', 'off'], true);
    return [
        'app_name' => $g('VP_APP_NAME', 'Vagtløn'), 'base_url' => rtrim($base, '/'), 'mail_from' => $g('VP_MAIL_FROM', 'noreply@example.com'),
        'admin_emails' => array_values(array_filter(array_map('trim', explode(',', (string)$g('VP_ADMIN_EMAILS', ''))))),
        'registration_open' => $bool($g('VP_REGISTRATION_OPEN'), true), 'require_verified' => $bool($g('VP_REQUIRE_VERIFIED'), true),
        'data_dir' => $g('VP_DATA_DIR', '/appdata'), 'controller' => $g('VP_CONTROLLER', ''), 'contact_email' => $g('VP_CONTACT_EMAIL', ''),
        'smtp_host' => $g('VP_SMTP_HOST', ''), 'smtp_port' => (int)$g('VP_SMTP_PORT', '587'), 'smtp_user' => $g('VP_SMTP_USER', ''), 'smtp_pass' => $g('VP_SMTP_PASS', ''),
        'smtp_secure' => $g('VP_SMTP_SECURE', 'tls'), 'smtp_verify' => $bool($g('VP_SMTP_VERIFY'), true),
    ];
}
$cfgFile = __DIR__ . '/config.php';
if (is_file($cfgFile)) $cfg = require $cfgFile;
elseif (($cfg = envCfg()) === null) fail('Serveren er ikke sat op endnu (config.php mangler).', 503);
if (!extension_loaded('pdo_sqlite')) fail('Serveren mangler SQLite-understøttelse (pdo_sqlite).', 503);


/* Bygger kalenderfilen på serveren ud fra den gemte plan, så abonnementet følger med, uanset hvilken enhed der ændrede planen. */
function icsFold(string $l): string { $o = ''; while (strlen($l) > 74) { $cut = 74; while ($cut > 0 && (ord($l[$cut]) & 0xC0) === 0x80) $cut--; $o .= substr($l, 0, $cut) . "\r\n "; $l = substr($l, $cut); } return $o . $l; }
function icsEsc(string $t): string { return str_replace(["\\", ";", ",", "\r\n", "\n"], ["\\\\", "\;", "\\,", "\\n", "\\n"], $t); }
function buildIcs(string $json, int $version): ?string {
    $S = json_decode($json, true); if (!is_array($S)) return null;
    $emps = []; foreach (($S['emps'] ?? []) as $e) if (is_array($e) && isset($e['id'])) $emps[(string)$e['id']] = $e;
    $tm = fn(string $t): int => (int)substr($t, 0, 2) * 60 + (int)substr($t, 3, 2);
    $stamp = gmdate('Ymd\THis\Z');
    $co = is_array($S['cal'] ?? null) ? $S['cal'] : [];
    $oDesc = !empty($co['d']); $oIco = !empty($co['i']); $oWk = !empty($co['w']); $oAl = in_array((int)($co['a'] ?? 0), [30, 60, 120], true) ? (int)$co['a'] : 0;
    $weeks = [];
    $o = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Vagtlon//DA', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Vagtløn', 'X-WR-TIMEZONE:Europe/Copenhagen', 'REFRESH-INTERVAL;VALUE=DURATION:PT15M', 'X-PUBLISHED-TTL:PT15M'];
    $plan = is_array($S['plan'] ?? null) ? $S['plan'] : []; ksort($plan); $n = 0;
    foreach ($plan as $k => $v) {
        if (!is_string($k) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $k) || !is_string($v) || !str_contains($v, '|')) continue;
        [$eid, $sid] = explode('|', $v, 2);
        $sh = null; foreach (($S['shifts'][$eid] ?? []) as $x) if (($x['id'] ?? '') === $sid) { $sh = $x; break; }
        if (!$sh) continue;
        $d = new DateTimeImmutable($k . 'T00:00:00'); $wd = ((int)$d->format('w') + 6) % 7;
        $t = !empty($sh['byDay']) ? ($sh['t'][$wd] ?? null) : ($sh['t'][0] ?? null);
        if (!is_array($t) || empty($t[0]) || empty($t[1])) continue;
        $next = !empty($t[2]) || $tm($t[1]) <= $tm($t[0]);
        $end = $next ? $d->modify('+1 day') : $d;
        $dep = (string)($emps[$eid]['dep'] ?? '');
        $desc = [];
        $ot = (float)($S['otd'][$k] ?? 0); if ($ot > 0) $desc[] = 'Merarbejde: ' . rtrim(rtrim(number_format($ot, 2, ',', ''), '0'), ',') . ' t';
        if (!empty($S['cmt'][$k])) $desc[] = (string)$S['cmt'][$k];
        $ev = ['BEGIN:VEVENT', 'UID:' . $k . $sid . '@vagtplan', 'DTSTAMP:' . $stamp, 'LAST-MODIFIED:' . $stamp, 'SEQUENCE:' . $version,
            'DTSTART:' . $d->format('Ymd') . 'T' . str_replace(':', '', $t[0]) . '00',
            'DTEND:' . $end->format('Ymd') . 'T' . str_replace(':', '', $t[1]) . '00',
            'SUMMARY:' . icsEsc(($oIco ? (!empty($sh['leave']) ? '🏖️ ' : (($h0 = (int)substr($t[0], 0, 2)) >= 21 || $h0 < 5 ? '🌙 ' : ($h0 >= 14 ? '🌆 ' : '☀️ '))) : '') . trim((!empty($sh['name']) ? $sh['name'] . (($sh['ab'] ?? '') !== '' ? ' (' . $sh['ab'] . ')' : '') : ($sh['ab'] ?? '')) . ($dep !== '' ? ' – ' . $dep : '')))];
        if ($dep !== '') $ev[] = 'LOCATION:' . icsEsc($dep);
        if ($oDesc && empty($sh['leave'])) { $mins = $tm($t[1]) - $tm($t[0]); if ($mins <= 0) $mins += 1440; array_unshift($desc, $t[0] . '–' . $t[1] . ' · ' . rtrim(rtrim(number_format($mins / 60, 2, ',', ''), '0'), ',') . ' t' . ($dep !== '' ? ' · ' . $dep : '')); }
        if ($desc) $ev[] = 'DESCRIPTION:' . icsEsc(implode("\n", $desc));
        if ($oAl && empty($sh['leave'])) array_push($ev, 'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:Vagt om ' . $oAl . ' min', 'TRIGGER:-PT' . $oAl . 'M', 'END:VALARM');
        if ($oWk) $weeks[$d->modify('monday this week')->format('Ymd')] = $d->format('W');
        $ev[] = 'TRANSP:' . (!empty($sh['leave']) ? 'TRANSPARENT' : 'OPAQUE'); $ev[] = 'END:VEVENT';
        array_push($o, ...$ev); if (++$n > 6000) break;
    }
    foreach ($emps as $e) foreach (($e['evacs'] ?? []) as $v) {
        if (empty($v['sd']) || empty($v['ed']) || empty($v['st']) || empty($v['et'])) continue;
        array_push($o, 'BEGIN:VEVENT', 'UID:ev' . ($v['id'] ?? $v['sd']) . '@vagtplan', 'DTSTAMP:' . $stamp, 'SEQUENCE:' . $version,
            'DTSTART:' . str_replace('-', '', $v['sd']) . 'T' . str_replace(':', '', $v['st']) . '00',
            'DTEND:' . str_replace('-', '', $v['ed']) . 'T' . str_replace(':', '', $v['et']) . '00',
            'SUMMARY:' . icsEsc('Evakuering (' . ($e['dep'] ?? '') . ')'), 'END:VEVENT');
    }
    foreach ($weeks as $ymd => $wk) { $nx = (new DateTimeImmutable($ymd))->modify('+1 day')->format('Ymd'); array_push($o, 'BEGIN:VEVENT', 'UID:uge' . $ymd . '@vagtplan', 'DTSTAMP:' . $stamp, 'DTSTART;VALUE=DATE:' . $ymd, 'DTEND;VALUE=DATE:' . $nx, 'SUMMARY:Uge ' . (int)$wk, 'TRANSP:TRANSPARENT', 'END:VEVENT'); }
    $o[] = 'END:VCALENDAR';
    return implode("\r\n", array_map('icsFold', $o)) . "\r\n";
}

$action = $_GET['a'] ?? '';
$isPost = PHP_SAPI !== 'cli' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
if ($isPost) {
    /* CSRF: kræver en egen header og JSON. Kan ikke sendes fra et andet website uden CORS. */
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'vagtplan') fail('Ugyldig forespørgsel.', 403);
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) fail('Ugyldig forespørgsel.', 415);
}
$raw = $isPost ? file_get_contents('php://input', false, null, 0, 4_000_000) : '';
$body = $isPost ? (json_decode($raw ?: '{}', true) ?: []) : [];

$dir = $cfg['data_dir'] ?? (__DIR__ . '/data');
if (!is_dir($dir)) { @mkdir($dir, 0700, true); }
if (!is_file($dir . '/.htaccess')) { @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n"); @file_put_contents($dir . '/index.html', ''); }
try {
    $db = new PDO('sqlite:' . $dir . '/app.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    /* Journal: WAL er hurtigst, men kan gå i stykker på netværksdiske, som nogle webhoteller bruger. Derfor er standarden «delete»
       (sikker alle steder) med config.php og «wal» med Docker/miljøvariabler (egen disk). Kan overstyres med 'sqlite_journal' / VP_SQLITE_JOURNAL. */
    $jm = strtolower((string)($cfg['sqlite_journal'] ?? (getenv('VP_SQLITE_JOURNAL') ?: (is_file($cfgFile) ? 'delete' : 'wal'))));
    $db->exec('PRAGMA journal_mode=' . ($jm === 'wal' ? 'WAL' : 'DELETE') . '; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;');
    $db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE, pass TEXT NOT NULL, created INTEGER NOT NULL, last_seen INTEGER, verified INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS verifs(th TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS normshare(id TEXT PRIMARY KEY, dk TEXT NOT NULL, lv TEXT NOT NULL, lag TEXT NOT NULL, d_from TEXT NOT NULL, d_to TEXT NOT NULL, hrs REAL NOT NULL, vt TEXT NOT NULL, created INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS normshare_by(id TEXT NOT NULL REFERENCES normshare(id) ON DELETE CASCADE, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(id,uid));
      CREATE TABLE IF NOT EXISTS shiftshare(id TEXT PRIMARY KEY, dk TEXT NOT NULL, j TEXT NOT NULL, created INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS shiftshare_by(id TEXT NOT NULL REFERENCES shiftshare(id) ON DELETE CASCADE, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(id,uid));
      CREATE TABLE IF NOT EXISTS normshare_use(id TEXT NOT NULL REFERENCES normshare(id) ON DELETE CASCADE, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, at INTEGER NOT NULL, PRIMARY KEY(id,uid));
      CREATE TABLE IF NOT EXISTS shiftshare_use(id TEXT NOT NULL REFERENCES shiftshare(id) ON DELETE CASCADE, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, at INTEGER NOT NULL, PRIMARY KEY(id,uid));
      CREATE TABLE IF NOT EXISTS trophy_list(id INTEGER PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, at INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', seen INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS share_seen(uid INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, at INTEGER NOT NULL);
      CREATE INDEX IF NOT EXISTS ns_k ON normshare(dk,lv);
      CREATE INDEX IF NOT EXISTS ss_k ON shiftshare(dk);
      CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS pv(day TEXT NOT NULL, page TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day,page));
      CREATE TABLE IF NOT EXISTS uv(day TEXT NOT NULL, page TEXT NOT NULL, vid TEXT NOT NULL, PRIMARY KEY(day,page,vid));
      CREATE TABLE IF NOT EXISTS refs(day TEXT NOT NULL, host TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day,host));
      CREATE TABLE IF NOT EXISTS sessions(th TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS states(uid INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data TEXT NOT NULL, version INTEGER NOT NULL, updated INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS cals(uid INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, tok TEXT NOT NULL UNIQUE, ics TEXT NOT NULL, updated INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS resets(th TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS attempts(k TEXT NOT NULL, t INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, kind TEXT NOT NULL, msg TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ny', created TEXT NOT NULL, updated TEXT NOT NULL, adm_upd TEXT NOT NULL DEFAULT '', ctx TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', thread TEXT NOT NULL DEFAULT '[]');
      CREATE TABLE IF NOT EXISTS tk_img(id TEXT PRIMARY KEY, tid TEXT NOT NULL, mime TEXT NOT NULL, data BLOB NOT NULL, created TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS tk_img_tid ON tk_img(tid);
      CREATE INDEX IF NOT EXISTS tk_uid ON tickets(uid,updated);
      CREATE INDEX IF NOT EXISTS att ON attempts(k,t);");
    /* Delinger: tidspunkt for hvornår den enkelte bruger delte (ældre rækker har 0 og viser delingens oprettelsestid). */
    foreach (['normshare_by', 'shiftshare_by'] as $tb) { $has = false; foreach ($db->query("PRAGMA table_info($tb)")->fetchAll(PDO::FETCH_ASSOC) as $c) if ($c['name'] === 'at') $has = true; if (!$has) $db->exec("ALTER TABLE $tb ADD COLUMN at INTEGER NOT NULL DEFAULT 0"); }
    /* Ældre databaser: eksisterende konti regnes som bekræftede. */
    $hasVer = false; foreach ($db->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_ASSOC) as $c) if ($c['name'] === 'verified') $hasVer = true;
    { $hs = false; foreach ($db->query('PRAGMA table_info(trophy_list)')->fetchAll(PDO::FETCH_ASSOC) as $c) if ($c['name'] === 'seen') $hs = true; if (!$hs) $db->exec('ALTER TABLE trophy_list ADD COLUMN seen INTEGER NOT NULL DEFAULT 0'); }
    if (fc($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='trophies'"))) { $db->exec("INSERT INTO trophy_list(uid,at,note) SELECT uid,at,note FROM trophies"); $db->exec('DROP TABLE trophies'); }
    if (!$hasVer) $db->exec('ALTER TABLE users ADD COLUMN verified INTEGER NOT NULL DEFAULT 1');
} catch (Throwable $e) { error_log('Vagtløn DB: ' . $e->getMessage()); fail('Databasen kunne ikke åbnes. Tjek at mappen data/ kan skrives til.', 500); }

$now = time();
/* Engangsflytning: vagtformer delt før faggruppe-opdelingen flyttes til delerens faggruppe (fra delerens gemte data). */
try {
    if (!fc($db->query("SELECT 1 FROM meta WHERE k='sf_grp_mig1'"))) {
        $okg = ['dk' => 'laege', 'gl' => 'laege', 'fo' => 'laege', 'sk' => 'sygepl', 'glpk' => 'sygepl', 'sosu' => 'sosu', 'efj' => 'fysio', 'por' => 'portor', 'amb' => 'ambu', 'shp' => 'sundpl', 'hk' => 'sekr', 'sped' => 'socped', 'spv' => 'lstud', 'lvik' => 'lstud'];
        $rows = $db->query("SELECT s.id,s.dk,s.j,s.created,b.uid,b.at FROM shiftshare s JOIN shiftshare_by b ON b.id=s.id WHERE s.dk NOT LIKE '%#%'")->fetchAll(PDO::FETCH_ASSOC);
        $grp = [];
        foreach ($rows as $r) {
            $uid = (int)$r['uid'];
            if (!array_key_exists($uid, $grp)) {
                $q = $db->prepare('SELECT data FROM states WHERE uid=?'); $q->execute([$uid]); $d = json_decode((string)fc($q), true); $g = '';
                if (is_array($d)) { $g = (string)($d['grp'] ?? ''); if ($g === '' && !empty($d['emps'][0]['ok'])) $g = $okg[$d['emps'][0]['ok']] ?? ''; }
                $grp[$uid] = preg_match('/^[a-z]{2,12}$/', $g) ? $g : '';
            }
            if ($grp[$uid] === '') continue;
            $ndk = $r['dk'] . '#' . $grp[$uid]; $nid = substr(hash('sha256', $ndk . '|' . $r['j']), 0, 32);
            $db->prepare('INSERT OR IGNORE INTO shiftshare(id,dk,j,created) VALUES(?,?,?,?)')->execute([$nid, $ndk, $r['j'], $r['created']]);
            $db->prepare('INSERT OR IGNORE INTO shiftshare_by(id,uid,at) VALUES(?,?,?)')->execute([$nid, $uid, $r['at'] ?: $r['created']]);
            $db->prepare('INSERT OR IGNORE INTO shiftshare_use(id,uid,at) SELECT ?,uid,at FROM shiftshare_use WHERE id=?')->execute([$nid, $r['id']]);
            $db->prepare('DELETE FROM shiftshare_by WHERE id=? AND uid=?')->execute([$r['id'], $uid]);
        }
        shareGc($db);
        $db->prepare("INSERT OR IGNORE INTO meta(k,v) VALUES('sf_grp_mig1',?)")->execute([(string)$now]);
    }
} catch (Throwable $e) { error_log('Vagtløn delingsflytning: ' . $e->getMessage()); }
if (random_int(1, 50) === 1) {
    $db->prepare('DELETE FROM sessions WHERE expires<?')->execute([$now]);
    $db->prepare('DELETE FROM verifs WHERE expires<?')->execute([$now]);
    shareGc($db);
    $db->prepare('DELETE FROM resets WHERE expires<?')->execute([$now]);
    $db->prepare('DELETE FROM attempts WHERE t<?')->execute([$now - 86400]);
    $db->prepare('DELETE FROM uv WHERE day<?')->execute([date('Y-m-d', $now - 45 * 86400)]);
    $db->prepare('DELETE FROM pv WHERE day<?')->execute([date('Y-m-d', $now - 800 * 86400)]);
    $db->prepare('DELETE FROM refs WHERE day<?')->execute([date('Y-m-d', $now - 800 * 86400)]);
}

/* Kommandolinje (kun fra serverens terminal): php api/index.php users | verify EMAIL | passwd EMAIL | backup */
function cliMain(PDO $db, array $cfg, array $argv): void {
    $cmd = $argv[1] ?? 'help'; $arg = strtolower(trim((string)($argv[2] ?? '')));
    $uid = function () use ($db, $arg) { $q = $db->prepare('SELECT id FROM users WHERE email=?'); $q->execute([$arg]); return fc($q); };
    switch ($cmd) {
        case 'users':
            foreach ($db->query('SELECT email,verified,created,last_seen FROM users ORDER BY created')->fetchAll(PDO::FETCH_ASSOC) as $r)
                echo str_pad($r['email'], 40) . ($r['verified'] ? 'bekræftet   ' : 'IKKE bekræftet ') . date('Y-m-d', (int)$r['created']) . "\n";
            break;
        case 'verify':
            if (!$uid()) { fwrite(STDERR, "Ingen bruger med den e-mail.\n"); exit(1); }
            $db->prepare('UPDATE users SET verified=1 WHERE id=?')->execute([$uid()]); echo "Bekræftet: $arg\n"; break;
        case 'passwd':
            if (!$uid()) { fwrite(STDERR, "Ingen bruger med den e-mail.\n"); exit(1); }
            $pw = bin2hex(random_bytes(7)); $db->prepare('UPDATE users SET pass=?, verified=1 WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $uid()]);
            $db->prepare('DELETE FROM sessions WHERE uid=?')->execute([$uid()]); echo "Ny midlertidig adgangskode til $arg: $pw\nSkift den under Opsætning, Konto, efter login.\n"; break;
        case 'backup': {
            $dir = ($cfg['data_dir'] ?? (__DIR__ . '/data')) . '/backups'; if (!is_dir($dir)) @mkdir($dir, 0700, true);
            $f = $dir . '/app-' . date('Ymd-His') . '.sqlite'; $db->exec('VACUUM INTO ' . $db->quote($f));
            $db = null; if (function_exists('gzencode')) { file_put_contents($f . '.gz', gzencode((string)file_get_contents($f), 9)); unlink($f); $f .= '.gz'; }
            $all = glob($dir . '/app-*') ?: []; sort($all); foreach (array_slice($all, 0, max(0, count($all) - 14)) as $old) @unlink($old);
            echo "Sikkerhedskopi: $f\n"; break;
        }
        default: echo "Brug: php api/index.php users | verify EMAIL | passwd EMAIL | backup\n";
    }
}
function limit(PDO $db, string $key, int $max, int $win): void {
    $now = time();
    $q = $db->prepare('SELECT COUNT(*) FROM attempts WHERE k=? AND t>?'); $q->execute([$key, $now - $win]);
    if ((int)fc($q) >= $max) fail('For mange forsøg. Prøv igen senere.', 429);
}
if (PHP_SAPI === 'cli' || defined('VP_CRON')) { cliMain($db, $cfg, $argv); exit(0); }
function hit(PDO $db, string $key): void { $db->prepare('INSERT INTO attempts(k,t) VALUES(?,?)')->execute([$key, time()]); }
function hashTok(string $t): string { return hash('sha256', $t); }
function email(array $b): string { $e = strtolower(trim((string)($b['email'] ?? ''))); if (!filter_var($e, FILTER_VALIDATE_EMAIL) || strlen($e) > 200) fail('Skriv en gyldig e-mailadresse.'); return $e; }
function pw(array $b, string $k = 'password'): string { $p = (string)($b[$k] ?? ''); if (strlen($p) < 10) fail('Adgangskoden skal være mindst 10 tegn.'); if (strlen($p) > 200) fail('Adgangskoden er for lang.'); return $p; }
function https(): bool { return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'); }
function startSession(PDO $db, int $uid): void {
    $tok = bin2hex(random_bytes(32)); $exp = time() + 60 * 86400;
    $db->prepare('INSERT INTO sessions(th,uid,expires) VALUES(?,?,?)')->execute([hashTok($tok), $uid, $exp]);
    setcookie('vp_sess', $tok, ['expires' => $exp, 'path' => '/', 'secure' => https(), 'httponly' => true, 'samesite' => 'Lax']);
}
function endCookie(): void { setcookie('vp_sess', '', ['expires' => 1, 'path' => '/', 'secure' => https(), 'httponly' => true, 'samesite' => 'Lax']); }
function authUser(PDO $db): ?array {
    $t = $_COOKIE['vp_sess'] ?? ''; if (!is_string($t) || $t === '') return null;
    $q = $db->prepare('SELECT u.id,u.email,u.last_seen FROM sessions s JOIN users u ON u.id=s.uid WHERE s.th=? AND s.expires>?');
    $q->execute([hashTok($t), time()]); $r = fr($q);
    if ($r && (int)$r['last_seen'] < time() - 1800) $db->prepare('UPDATE users SET last_seen=? WHERE id=?')->execute([time(), $r['id']]);
    return $r ?: null;
}
/* Mail: egen SMTP-klient (ingen afhængigheder), ellers PHP's mail(). Returnerer true, hvis mailen blev afleveret til mailserveren. */
function smtpRead($fp): array {
    $text = ''; $code = 0;
    while (($l = fgets($fp, 1024)) !== false) { $text .= $l; $code = (int)substr($l, 0, 3); if (strlen($l) < 4 || $l[3] !== '-') break; }
    return [$code, $text];
}
function smtpCmd($fp, string $cmd, array $ok): string {
    if ($cmd !== '') fwrite($fp, $cmd . "\r\n");
    [$code, $text] = smtpRead($fp);
    if (!in_array($code, $ok, true)) throw new RuntimeException("SMTP $code: " . trim($text));
    return $text;
}
/* Samler brødteksten: ren tekst, eller tekst + HTML som multipart/alternative. Returnerer [Content-Type-header, krop]. */
function mailBody(string $text, ?string $html): array {
    $b64 = fn(string $t) => chunk_split(base64_encode($t), 76, "\r\n");
    if ($html === null) return ['Content-Type: text/plain; charset=UTF-8' . "\r\n" . 'Content-Transfer-Encoding: base64', $b64($text)];
    $bd = 'vl_' . bin2hex(random_bytes(10));
    $body = "--$bd\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . $b64($text)
          . "--$bd\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . $b64($html) . "--$bd--\r\n";
    return ["Content-Type: multipart/alternative; boundary=\"$bd\"", $body];
}
/* Mail i appens udtryk: marineblå top, tydelig knap, enkel tekst. Alt er inline, så mailklienter viser det rigtigt. */
function mailHtml(array $cfg, string $title, string $intro, ?string $btn, ?string $url, string $foot): string {
    $e = fn($t) => htmlspecialchars($t, ENT_QUOTES, 'UTF-8'); $app = $e((string)($cfg['app_name'] ?? 'Vagtløn')); $base = rtrim((string)($cfg['base_url'] ?? ''), '/');
    $b = ($btn && $url) ? '<tr><td style="padding:6px 32px 8px"><a href="' . $e($url) . '" style="display:inline-block;background:#f09a2a;color:#14213d;text-decoration:none;font-weight:700;font-size:16px;padding:14px 28px;border-radius:10px">' . $e($btn) . '</a></td></tr><tr><td style="padding:10px 32px 0;font-size:12.5px;color:#6b7686;line-height:1.5">Virker knappen ikke? Kopiér dette link ind i din browser:<br><a href="' . $e($url) . '" style="color:#0b6e8a;word-break:break-all">' . $e($url) . '</a></td></tr>' : '';
    return '<!doctype html><html lang="da"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $e($title) . '</title></head>'
      . '<body style="margin:0;background:#eef1f5;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#14213d">'
      . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef1f5"><tr><td align="center" style="padding:28px 12px">'
      . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#ffffff;border-radius:14px;overflow:hidden">'
      . '<tr><td style="background:#14213d;padding:22px 32px"><table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="vertical-align:middle"><img src="' . $e($base) . '/icon-192.png" width="34" height="34" alt="" style="display:block;border-radius:8px"></td><td style="vertical-align:middle;padding-left:12px;color:#ffffff;font-size:22px;font-weight:800;letter-spacing:-.01em">' . $app . '</td></tr></table></td></tr>'
      . '<tr><td style="padding:30px 32px 6px"><h1 style="margin:0 0 12px;font-size:23px;line-height:1.25;color:#14213d">' . $e($title) . '</h1><p style="margin:0 0 18px;font-size:16px;line-height:1.55;color:#2b3648">' . $intro . '</p></td></tr>'
      . $b
      . '<tr><td style="padding:26px 32px 30px;font-size:12.5px;line-height:1.55;color:#6b7686;border-top:0">' . $foot . '</td></tr>'
      . '</table><p style="max-width:520px;margin:14px auto 0;font-size:11.5px;color:#8a94a3;line-height:1.5">' . $app . ' er et uafhængigt hjælpeværktøj til vagter, løn og overenskomst.</p></td></tr></table></body></html>';
}
function smtpSend(array $cfg, string $to, string $subject, string $text, ?string $html = null): void {
    $host = (string)$cfg['smtp_host']; $port = (int)($cfg['smtp_port'] ?? 587); $sec = strtolower((string)($cfg['smtp_secure'] ?? 'tls'));
    $verify = (bool)($cfg['smtp_verify'] ?? true);
    $ctx = stream_context_create(['ssl' => ['verify_peer' => $verify, 'verify_peer_name' => $verify, 'allow_self_signed' => !$verify, 'peer_name' => $host]]);
    $fp = @stream_socket_client(($sec === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) throw new RuntimeException("SMTP: kunne ikke forbinde til $host:$port ($es)");
    stream_set_timeout($fp, 20);
    try {
        $me = parse_url((string)($cfg['base_url'] ?? ''), PHP_URL_HOST) ?: 'localhost';
        smtpCmd($fp, '', [220]);
        $ext = smtpCmd($fp, "EHLO $me", [250]);
        if ($sec === 'tls') {
            smtpCmd($fp, 'STARTTLS', [220]);
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('SMTP: TLS kunne ikke startes');
            $ext = smtpCmd($fp, "EHLO $me", [250]);
        }
        $user = (string)($cfg['smtp_user'] ?? ''); $pass = (string)($cfg['smtp_pass'] ?? '');
        if ($user !== '') {
            if (stripos($ext, 'AUTH') !== false && stripos($ext, 'PLAIN') !== false) smtpCmd($fp, 'AUTH PLAIN ' . base64_encode("\0$user\0$pass"), [235]);
            else { smtpCmd($fp, 'AUTH LOGIN', [334]); smtpCmd($fp, base64_encode($user), [334]); smtpCmd($fp, base64_encode($pass), [235]); }
        }
        $from = str_replace(["\r", "\n", '<', '>'], '', (string)($cfg['mail_from'] ?? 'noreply@example.com')); $name = str_replace(["\r", "\n"], '', (string)($cfg['app_name'] ?? 'Vagtløn'));
        smtpCmd($fp, "MAIL FROM:<$from>", [250]); smtpCmd($fp, "RCPT TO:<$to>", [250, 251]); smtpCmd($fp, 'DATA', [354]);
        $head = ['Date: ' . date('r'), 'From: =?UTF-8?B?' . base64_encode($name) . "?= <$from>", "To: <$to>", 'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=',
            'Message-ID: <' . bin2hex(random_bytes(12)) . "@$me>", 'MIME-Version: 1.0', 'Auto-Submitted: auto-generated'];
        [$ct, $bodyOut] = mailBody($text, $html);
        fwrite($fp, implode("\r\n", $head) . "\r\n" . $ct . "\r\n\r\n" . $bodyOut . ".\r\n");
        smtpCmd($fp, '', [250]);
        @smtpCmd($fp, 'QUIT', [221]);
    } finally { @fclose($fp); }
}
function mailTo(array $cfg, string $to, string $subject, string $text, ?string $html = null): bool {
    $to = str_replace(["\r", "\n", '<', '>'], '', $to);
    try {
        if (!empty($cfg['smtp_host'])) { smtpSend($cfg, $to, $subject, $text, $html); return true; }
        $from = $cfg['mail_from'] ?? 'noreply@example.com'; $name = $cfg['app_name'] ?? 'Vagtløn';
        [$ct, $bodyOut] = mailBody($text, $html);
        $h = "From: =?UTF-8?B?" . base64_encode($name) . "?= <" . str_replace(["\r", "\n"], '', $from) . ">\r\nMIME-Version: 1.0\r\n" . $ct;
        return @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $bodyOut, $h);
    } catch (Throwable $e) { error_log('Vagtløn mail: ' . $e->getMessage()); return false; }
}
function sendVerify(PDO $db, array $cfg, int $uid, string $email): bool {
    $tok = bin2hex(random_bytes(32));
    /* Ældre, endnu gyldige links bliver stående (højst 4), så et link fra en tidligere mail ikke pludselig virker som udløbet */
    $db->prepare('DELETE FROM verifs WHERE uid=? AND expires<=?')->execute([$uid, time()]);
    $db->prepare('DELETE FROM verifs WHERE uid=? AND th NOT IN (SELECT th FROM verifs WHERE uid=? ORDER BY expires DESC LIMIT 3)')->execute([$uid, $uid]);
    $db->prepare('INSERT INTO verifs(th,uid,expires) VALUES(?,?,?)')->execute([hashTok($tok), $uid, time() + 2 * 86400]);
    $base = rtrim((string)($cfg['base_url'] ?? ''), '/'); $app = $cfg['app_name'] ?? 'Vagtløn';
    $url = "$base/api/?a=verify&t=$tok";
    $html = mailHtml($cfg, 'Bekræft din e-mail', 'Tak, fordi du har oprettet en konto i ' . htmlspecialchars($app) . '. Tryk på knappen for at bekræfte din e-mailadresse og komme i gang.', 'Bekræft e-mail', $url, 'Linket virker i to døgn. Har du ikke oprettet en konto, kan du se bort fra denne e-mail.');
    return mailTo($cfg, $email, 'Bekræft din e-mail til ' . $app, "Hej\n\nBekræft din e-mailadresse for at komme i gang med $app.\nÅbn dette link inden for to døgn:\n\n$url\n\nHar du ikke oprettet en konto, kan du se bort fra denne e-mail.\n", $html);
}
function needVerify(array $cfg): bool { return (bool)($cfg['require_verified'] ?? true); }
function htmlPage(string $title, string $body, string $base): never {
    header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); header('Referrer-Policy: no-referrer');
    echo '<!doctype html><html lang="da"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . htmlspecialchars($title) . '</title><style>body{font:16px/1.5 system-ui,sans-serif;margin:0;background:#f4f6f8;color:#14213d}main{max-width:460px;margin:12vh auto;padding:0 18px}.c{background:#fff;border:1px solid #dde2ea;border-radius:12px;padding:22px}a.b{display:inline-block;margin-top:10px;background:#0b6e8a;color:#fff;text-decoration:none;padding:10px 16px;border-radius:8px}@media(prefers-color-scheme:dark){body{background:#10151f;color:#e8edf5}.c{background:#18202e;border-color:#2a3547}}</style></head><body><main><div class="c"><h1 style="margin:0 0 8px;font-size:22px">' . htmlspecialchars($title) . '</h1>' . $body . '<a class="b" href="' . htmlspecialchars($base) . '/app.html">Til appen</a></div></main></body></html>';
    exit;
}
/* Delte normperioder og vagtformer: anonyme, og fjernes automatisk, når den sidste der delte dem, slettes. */
function shareGc(PDO $db): void {
    $db->exec('DELETE FROM normshare WHERE id NOT IN (SELECT id FROM normshare_by)');
    $db->exec('DELETE FROM shiftshare WHERE id NOT IN (SELECT id FROM shiftshare_by)');
}
function validDate(string $d): bool { return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4)); }
$ip = $_SERVER['REMOTE_ADDR'] ?? '0';
function isAdmin(array $cfg, string $e): bool { return in_array(strtolower($e), array_map('strtolower', $cfg['admin_emails'] ?? []), true); }
function secret(PDO $db): string {
    $q = $db->query("SELECT v FROM meta WHERE k='secret'"); $v = fc($q);
    if (!$v) { $v = bin2hex(random_bytes(32)); $db->prepare("INSERT OR IGNORE INTO meta(k,v) VALUES('secret',?)")->execute([$v]); $q = $db->query("SELECT v FROM meta WHERE k='secret'"); $v = fc($q); }
    return (string)$v;
}
function adminOnly(PDO $db, array $cfg): array { $u = authUser($db); if (!$u || !isAdmin($cfg, $u['email'])) fail('Ingen adgang.', 403); return $u; }
function notifySignup(PDO $db, array $cfg, string $newEmail, bool $verified): void {
    try {
        $tot = (int)fc($db->query('SELECT COUNT(*) FROM users'));
        $q = $db->query("SELECT k FROM meta WHERE k LIKE 'notify_signup:%' AND v='1'");
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $k) {
            $to = substr((string)$k, strlen('notify_signup:'));
            if (!$to || !isAdmin($cfg, $to)) continue;
            mailTo($cfg, $to, 'Ny bruger på Vagtløn', "Der er oprettet en ny konto på Vagtløn.\n\nE-mail: $newEmail\nStatus: " . ($verified ? 'bekræftet' : 'afventer bekræftelse') . "\nBrugere i alt: $tot\n\nDu kan slå denne besked fra under Statistik i adminpanelet.");
        }
    } catch (Throwable $e) { /* en notifikation må aldrig forhindre oprettelsen */ }
}

/* Henvendelser (tickets) */
const TK_KINDS = ['fejl', 'forslag', 'spoerg', 'ok', 'lon'];
const TK_STATUS = ['ny', 'igang', 'adr', 'loest'];
function tkNow(): string { return gmdate('Y-m-d\TH:i:s') . '.000Z'; }
function tkOut(array $r, bool $adm, int $me): array {
    $th = json_decode((string)$r['thread'], true); if (!is_array($th)) $th = [];
    $o = ['id' => $r['id'], 'k' => $r['kind'], 'm' => $r['msg'], 'st' => $r['status'], 'c' => $r['created'], 'u' => $r['updated'], 'ua' => $r['adm_upd'], 'th' => $th, 'own' => (int)$r['uid'] === $me];
    if ($adm) { $o['ctx'] = $r['ctx']; $o['em'] = $r['email']; }
    return $o;
}
function tkGet(PDO $db, string $id): ?array { $q = $db->prepare('SELECT * FROM tickets WHERE id=?'); $q->execute([$id]); $r = fr($q); return $r ?: null; }
function tkMsg(array $b): string { $m = trim((string)($b['m'] ?? '')); if (mb_strlen($m) < 1) fail('Skriv en besked.'); return mb_substr($m, 0, 3000); }
function tkNotifyAdmin(array $cfg, string $subject, string $text): void { foreach (($cfg['admin_emails'] ?? []) as $a) { if (is_string($a) && $a !== '') mailTo($cfg, $a, $subject, $text); } }

switch ($action) {
    case 'me': {
        $u = authUser($db); out(['user' => $u ? ['email' => $u['email'], 'admin' => isAdmin($cfg, $u['email'])] : null, 'admin' => $u && isAdmin($cfg, $u['email']), 'open' => (bool)($cfg['registration_open'] ?? true)]);
    }
    case 'okst': {
        $q = $db->query("SELECT v FROM meta WHERE k='okstatus'"); $v = fc($q);
        header('Cache-Control: public, max-age=60'); echo $v ?: '{}'; exit;
    }
    case 'okst_set': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg);
        $in = is_array($body['st'] ?? null) ? $body['st'] : []; $o = [];
        foreach ($in as $k => $x) {
            if (!is_string($k) || !preg_match('/^[a-z0-9_]{1,20}$/', $k) || !is_array($x)) continue;
            $t = (string)($x['t'] ?? ''); if (!in_array($t, ['ok', 'v', 'base', 'own', ''], true)) continue;
            $o[$k] = ['t' => $t, 'n' => mb_substr((string)($x['n'] ?? ''), 0, 80), 'note' => mb_substr((string)($x['note'] ?? ''), 0, 400)];
        }
        $db->prepare("INSERT OR REPLACE INTO meta(k,v) VALUES('okstatus',?)")->execute([json_encode($o, JSON_UNESCAPED_UNICODE)]); out(['ok' => true]);
    }
    case 'info': {
        header('Cache-Control: public, max-age=300'); out(['controller' => (string)($cfg['controller'] ?? ''), 'contact' => (string)($cfg['contact_email'] ?? ''), 'app' => (string)($cfg['app_name'] ?? 'Vagtløn')]);
    }
    case 'register': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        if (!($cfg['registration_open'] ?? true)) fail('Oprettelse er lukket.', 403);
        limit($db, "reg:$ip", 40, 3600); hit($db, "reg:$ip");
        $e = email($body); $p = pw($body);
        $q = $db->prepare('SELECT 1 FROM users WHERE email=?'); $q->execute([$e]);
        if (fc($q)) fail('Der findes allerede en konto med den e-mailadresse.', 409);
        $ver = needVerify($cfg) ? 0 : 1;
        $db->prepare('INSERT INTO users(email,pass,created,verified) VALUES(?,?,?,?)')->execute([$e, password_hash($p, PASSWORD_DEFAULT), time(), $ver]);
        $uid = (int)$db->lastInsertId();
        notifySignup($db, $cfg, $e, (bool)$ver);
        if (!$ver) {
            $sent = sendVerify($db, $cfg, $uid, $e);
            out(['pending' => true, 'msg' => $sent ? 'Kontoen er oprettet. Vi har sendt et bekræftelseslink til din e-mail (tjek også spam). Klik på det, og log så ind her.'
                : 'Kontoen er oprettet, men vi kunne ikke sende bekræftelsesmailen. Prøv at logge ind om lidt, så sender vi den igen.']);
        }
        startSession($db, $uid); out(['user' => ['email' => $e, 'admin' => isAdmin($cfg, $e)]]);
    }
    case 'login': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $e = email($body); $p = (string)($body['password'] ?? '');
        limit($db, "login:$ip", 150, 900); limit($db, "loginu:$e", 8, 900);
        $q = $db->prepare('SELECT id,pass,verified FROM users WHERE email=?'); $q->execute([$e]); $u = fr($q);
        $ok = password_verify($p, $u['pass'] ?? '$2y$10$abcdefghijklmnopqrstuuabcdefghijklmnopqrstuvwxyz01234');
        if (!$u || !$ok) { hit($db, "login:$ip"); hit($db, "loginu:$e"); fail('Forkert e-mail eller adgangskode.', 401); }
        if (needVerify($cfg) && !(int)$u['verified']) {
            if (!($cfg['smtp_host'] ?? '') && !function_exists('mail')) fail('Din e-mail er ikke bekræftet endnu.', 403);
            $sent = false; $q = $db->prepare('SELECT COUNT(*) FROM attempts WHERE k=? AND t>?'); $q->execute(["vm:{$u['id']}", time() - 3600]);
            if ((int)fc($q) < 3) { hit($db, "vm:{$u['id']}"); $sent = sendVerify($db, $cfg, (int)$u['id'], $e); }
            fail($sent ? 'Din e-mail er ikke bekræftet endnu. Vi har sendt et nyt bekræftelseslink (tjek også spam).' : 'Din e-mail er ikke bekræftet endnu. Brug linket i den mail, vi allerede har sendt, eller prøv igen senere.', 403);
        }
        startSession($db, (int)$u['id']); out(['user' => ['email' => $e, 'admin' => isAdmin($cfg, $e)]]);
    }
    case 'verify': {
        $base = rtrim((string)($cfg['base_url'] ?? ''), '/');
        limit($db, "vf:$ip", 200, 3600); hit($db, "vf:$ip");
        $t = (string)($_GET['t'] ?? '');
        $uid = preg_match('/^[a-f0-9]{64}$/', $t) ? (function () use ($db, $t) { $q = $db->prepare('SELECT uid FROM verifs WHERE th=? AND expires>?'); $q->execute([hashTok($t), time()]); return fc($q); })() : false;
        if (!$uid) htmlPage('Linket virker ikke', '<p>Linket er udløbet eller allerede brugt. Log ind i appen med din e-mail og adgangskode, så sender vi et nyt.</p>', $base);
        $db->prepare('UPDATE users SET verified=1 WHERE id=?')->execute([$uid]); $db->prepare('DELETE FROM verifs WHERE uid=?')->execute([$uid]);
        htmlPage('E-mailen er bekræftet', '<p>Tak. Din e-mail er bekræftet. Gå tilbage til appen og log ind med din e-mail og adgangskode, så guider vi dig videre til din første ansættelse.</p>', $base);
    }
    case 'logout': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $t = $_COOKIE['vp_sess'] ?? ''; if (is_string($t) && $t !== '') $db->prepare('DELETE FROM sessions WHERE th=?')->execute([hashTok($t)]);
        endCookie(); out(['ok' => true]);
    }
    case 'forgot': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $e = email($body); limit($db, "fg:$ip", 30, 3600); limit($db, "fgu:$e", 3, 3600); hit($db, "fg:$ip"); hit($db, "fgu:$e");
        $q = $db->prepare('SELECT id FROM users WHERE email=?'); $q->execute([$e]); $uid = fc($q);
        if ($uid) {
            $tok = bin2hex(random_bytes(32));
            $db->prepare('INSERT INTO resets(th,uid,expires) VALUES(?,?,?)')->execute([hashTok($tok), $uid, time() + 3600]);
            $base = rtrim((string)($cfg['base_url'] ?? ''), '/');
            $ru = "$base/app.html#reset=$tok"; $appn = (string)($cfg['app_name'] ?? 'Vagtløn');
            mailTo($cfg, $e, 'Nulstil din adgangskode', "Hej\n\nDu har bedt om at nulstille din adgangskode til $appn.\nÅbn dette link inden for en time:\n\n$ru\n\nHar du ikke bedt om det, kan du se bort fra denne e-mail.\n",
                mailHtml($cfg, 'Nulstil din adgangskode', 'Du har bedt om at vælge en ny adgangskode til ' . htmlspecialchars($appn) . '. Tryk på knappen for at gøre det.', 'Vælg ny adgangskode', $ru, 'Linket virker i en time. Har du ikke bedt om det, kan du se bort fra denne e-mail. Din adgangskode ændres ikke.'));
        }
        out(['ok' => true]);
    }
    case 'reset': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        limit($db, "rs:$ip", 60, 3600); hit($db, "rs:$ip");
        $p = pw($body); $t = (string)($body['token'] ?? '');
        $q = $db->prepare('SELECT uid FROM resets WHERE th=? AND expires>?'); $q->execute([hashTok($t), time()]); $uid = fc($q);
        if (!$uid) fail('Linket er udløbet eller allerede brugt. Bed om et nyt.', 400);
        $db->beginTransaction();
        $db->prepare('UPDATE users SET pass=?, verified=1 WHERE id=?')->execute([password_hash($p, PASSWORD_DEFAULT), $uid]);
        $db->prepare('DELETE FROM resets WHERE uid=?')->execute([$uid]);
        $db->prepare('DELETE FROM sessions WHERE uid=?')->execute([$uid]);
        $db->commit(); out(['ok' => true]);
    }
    case 'state': {
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        if (!$isPost) {
            $q = $db->prepare('SELECT data,version,updated FROM states WHERE uid=?'); $q->execute([$u['id']]); $r = fr($q);
            out($r ? ['s' => $r['data'], 'version' => (int)$r['version'], 'updated' => (int)$r['updated']] : ['s' => null, 'version' => 0]);
        }
        $s = $body['s'] ?? null; $v = (int)($body['version'] ?? 0);
        if (!is_string($s) || strlen($s) > 3_000_000 || json_decode($s) === null) fail('Ugyldige data.', 400);
        limit($db, "put:{$u['id']}", 600, 3600); hit($db, "put:{$u['id']}");
        $db->exec('BEGIN IMMEDIATE');
        $q = $db->prepare('SELECT data,version FROM states WHERE uid=?'); $q->execute([$u['id']]); $r = fr($q);
        $cur = $r ? (int)$r['version'] : 0;
        if ($cur !== $v) { $db->exec('ROLLBACK'); out(['conflict' => true, 's' => $r['data'] ?? null, 'version' => $cur], 409); }
        $db->prepare('INSERT INTO states(uid,data,version,updated) VALUES(?,?,?,?) ON CONFLICT(uid) DO UPDATE SET data=excluded.data,version=excluded.version,updated=excluded.updated')->execute([$u['id'], $s, $cur + 1, time()]);
        $db->exec('COMMIT');
        $c = $db->prepare('SELECT 1 FROM cals WHERE uid=?'); $c->execute([$u['id']]);
        if (fc($c)) { $ics = buildIcs($s, $cur + 1); if ($ics !== null) $db->prepare('UPDATE cals SET ics=?,updated=? WHERE uid=?')->execute([$ics, time(), $u['id']]); }
        out(['version' => $cur + 1]);
    }
    case 'password': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "pwc:{$u['id']}", 10, 3600); hit($db, "pwc:{$u['id']}");
        $q = $db->prepare('SELECT pass FROM users WHERE id=?'); $q->execute([$u['id']]);
        if (!password_verify((string)($body['current'] ?? ''), (string)fc($q))) fail('Nuværende adgangskode er forkert.', 401);
        $n = pw($body, 'next');
        $db->prepare('UPDATE users SET pass=? WHERE id=?')->execute([password_hash($n, PASSWORD_DEFAULT), $u['id']]); out(['ok' => true]);
    }
    case 'delete': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "del:{$u['id']}", 10, 3600); hit($db, "del:{$u['id']}");
        $q = $db->prepare('SELECT pass FROM users WHERE id=?'); $q->execute([$u['id']]);
        if (!password_verify((string)($body['password'] ?? ''), (string)fc($q))) fail('Adgangskoden er forkert.', 401);
        $db->prepare('DELETE FROM users WHERE id=?')->execute([$u['id']]); shareGc($db); endCookie(); out(['ok' => true]);
    }

    case 'np_list': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $dk = mb_substr((string)($body['dk'] ?? ''), 0, 199); $lv = mb_substr((string)($body['lv'] ?? ''), 0, 39);
        $q = $db->prepare('SELECT n.id,n.lag,n.d_from,n.d_to,n.hrs,n.vt,n.created,(SELECT COUNT(*) FROM normshare_by b WHERE b.id=n.id) c,(SELECT COUNT(*) FROM normshare_by b WHERE b.id=n.id AND b.uid=?) mine FROM normshare n WHERE n.dk=? AND n.lv=? ORDER BY n.d_from LIMIT 200');
        $q->execute([$u['id'], $dk, $lv]);
        out(['items' => array_map(fn($r) => ['id' => $r['id'], 'lag' => $r['lag'], 'from' => $r['d_from'], 'to' => $r['d_to'], 'hrs' => (float)$r['hrs'], 'vt' => $r['vt'], 'n' => (int)$r['c'], 'at' => (int)$r['created'], 'mine' => (int)$r['mine'] > 0], $q->fetchAll(PDO::FETCH_ASSOC))]);
    }
    case 'np_put': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "share:{$u['id']}", 60, 3600); hit($db, "share:{$u['id']}");
        $dk = (string)($body['dk'] ?? ''); $lv = (string)($body['lv'] ?? '');
        if ($dk === '' || mb_strlen($dk) > 199 || $lv === '' || mb_strlen($lv) > 39) fail('Afdeling og niveau mangler.');
        $n = 0;
        foreach (array_slice(is_array($body['items'] ?? null) ? $body['items'] : [], 0, 40) as $it) {
            if (!is_array($it)) continue;
            $lag = (string)($it['lag'] ?? ''); $f = (string)($it['from'] ?? ''); $t = (string)($it['to'] ?? ''); $h = (float)($it['hrs'] ?? 0); $vt = (string)($it['vt'] ?? '');
            if (mb_strlen($lag) > 40 || !validDate($f) || !validDate($t) || $t < $f || $h <= 0 || $h > 60 || !in_array($vt, ['', 'on', 'off', 'mix'], true)) continue;
            $id = substr(hash('sha256', implode('|', [$dk, $lv, $lag, $f, $t, $h, $vt])), 0, 32);
            $db->prepare('INSERT OR IGNORE INTO normshare(id,dk,lv,lag,d_from,d_to,hrs,vt,created) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$id, $dk, $lv, $lag, $f, $t, $h, $vt, time()]);
            $c = $db->prepare('SELECT COUNT(*) FROM normshare_by WHERE id=?'); $c->execute([$id]);
            if ((int)fc($c) < 500) $db->prepare('INSERT OR IGNORE INTO normshare_by(id,uid,at) VALUES(?,?,?)')->execute([$id, $u['id'], time()]);
            $n++;
        }
        if (!$n) fail('Ingen gyldige normperioder at dele.');
        out(['ok' => true, 'n' => $n]);
    }
    /* Henter en iCal-adresse (fx Loop/Allocate) for den indloggede bruger. Adressen gemmes og logges ikke her.
       Kun https, port 443, ingen interne adresser, højst 3 omdirigeringer og 3 MB. */
    case 'ical_fetch': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "ical:{$u['id']}", 40, 3600); hit($db, "ical:{$u['id']}");
        if (!function_exists('curl_init')) fail('Serveren kan ikke hente kalenderen.', 501);
        $url = trim((string)($body['url'] ?? ''));
        $safe = function (string $x): ?array {
            $p = parse_url($x);
            if (!$p || strtolower($p['scheme'] ?? '') !== 'https' || empty($p['host']) || isset($p['user']) || isset($p['pass'])) return null;
            if (isset($p['port']) && (int)$p['port'] !== 443) return null;
            $h = strtolower($p['host']);
            if (filter_var($h, FILTER_VALIDATE_IP) || !str_contains($h, '.') || preg_match('/(^|\.)(localhost|local|internal|lan)$/', $h)) return null;
            $ips = @gethostbynamel($h); if (!$ips) return null;
            foreach ($ips as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return null;
            return ['host' => $h, 'ip' => $ips[0]];
        };
        $txt = null; $err = 'Kalenderen kunne ikke hentes. Tjek linket.';
        for ($i = 0; $i < 4; $i++) {
            $sf = $safe($url); if (!$sf) { $err = 'Linket skal være en https-adresse til en kalender.'; break; }
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 6,
                CURLOPT_RESOLVE => [$sf['host'] . ':443:' . $sf['ip']], CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_USERAGENT => 'Vagtlon-kalenderhenter',
                CURLOPT_HEADER => true, CURLOPT_MAXFILESIZE => 3145728]);
            $r = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); $hs = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE); curl_close($ch);
            if ($r === false) break;
            if ($code >= 300 && $code < 400 && preg_match('/^location:\s*(\S+)/mi', substr($r, 0, $hs), $m)) { $url = $m[1]; continue; }
            if ($code !== 200) { $err = $code === 404 || $code === 403 ? 'Linket virker ikke (længere). Hent et nyt link i Loop.' : $err; break; }
            $b = substr($r, $hs); if (strlen($b) > 3 * 1024 * 1024) { $err = 'Kalenderen er for stor.'; break; }
            if (!str_contains($b, 'BEGIN:VCALENDAR')) { $err = 'Linket er ikke en kalender (iCal).'; break; }
            $txt = $b; break;
        }
        if ($txt === null) fail($err);
        out(['ok' => true, 'text' => $txt]);
    }
    case 'sf_list': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $q = $db->prepare('SELECT s.id,s.j,s.created,(SELECT COUNT(*) FROM shiftshare_by b WHERE b.id=s.id) c,(SELECT COUNT(*) FROM shiftshare_by b WHERE b.id=s.id AND b.uid=?) mine FROM shiftshare s WHERE s.dk=? ORDER BY s.created LIMIT 200');
        $q->execute([$u['id'], mb_substr((string)($body['dk'] ?? ''), 0, 199)]);
        out(['items' => array_map(fn($r) => ['id' => $r['id'], 'j' => $r['j'], 'n' => (int)$r['c'], 'at' => (int)$r['created'], 'mine' => (int)$r['mine'] > 0], $q->fetchAll(PDO::FETCH_ASSOC))]);
    }
    case 'sf_put': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "share:{$u['id']}", 60, 3600); hit($db, "share:{$u['id']}");
        $dk = (string)($body['dk'] ?? ''); if ($dk === '' || mb_strlen($dk) > 199) fail('Afdeling mangler.');
        $n = 0;
        foreach (array_slice(is_array($body['items'] ?? null) ? $body['items'] : [], 0, 40) as $js) {
            if (!is_string($js) || strlen($js) >= 1500 || !is_array(json_decode($js, true))) continue;
            $id = substr(hash('sha256', $dk . '|' . $js), 0, 32);
            $db->prepare('INSERT OR IGNORE INTO shiftshare(id,dk,j,created) VALUES(?,?,?,?)')->execute([$id, $dk, $js, time()]);
            $c = $db->prepare('SELECT COUNT(*) FROM shiftshare_by WHERE id=?'); $c->execute([$id]);
            if ((int)fc($c) < 500) $db->prepare('INSERT OR IGNORE INTO shiftshare_by(id,uid,at) VALUES(?,?,?)')->execute([$id, $u['id'], time()]);
            $n++;
        }
        if (!$n) fail('Ingen gyldige vagtformer at dele.');
        out(['ok' => true, 'n' => $n]);
    }
    /* Like, brug, træk tilbage og egne delinger (normperioder = np, vagtformer = sf). Alt er anonymt over for andre brugere. */
    case 'np_use': case 'sf_use': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "use:{$u['id']}", 240, 3600); hit($db, "use:{$u['id']}");
        $t = $action === 'np_use' ? 'normshare' : 'shiftshare';
        $id = (string)($body['id'] ?? ''); if (!preg_match('/^[a-f0-9]{32}$/', $id)) fail('Ugyldigt id.');
        $q = $db->prepare("SELECT 1 FROM $t WHERE id=?"); $q->execute([$id]); if (!fc($q)) fail('Delingen findes ikke mere.', 404);
        $q = $db->prepare("SELECT 1 FROM {$t}_by WHERE id=? AND uid=?"); $q->execute([$id, $u['id']]); if (fc($q)) fail('Det er din egen deling.');
        $db->prepare("INSERT OR IGNORE INTO {$t}_use(id,uid,at) VALUES(?,?,?)")->execute([$id, $u['id'], time()]);
        out(['ok' => true]);
    }
    case 'np_unshare': case 'sf_unshare': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "unshare:{$u['id']}", 120, 3600); hit($db, "unshare:{$u['id']}");
        $t = $action === "np_unshare" ? "normshare" : "shiftshare"; $ids = [];
        foreach (array_slice(is_array($body['ids'] ?? null) ? $body['ids'] : [], 0, 100) as $x) if (is_string($x) && preg_match('/^[a-f0-9]{32}$/', $x)) $ids[] = $x;
        $dk = (string)($body['dk'] ?? ''); $lv = (string)($body['lv'] ?? '');
        foreach (array_slice(is_array($body['items'] ?? null) ? $body['items'] : [], 0, 40) as $it) {
            if ($action === "np_unshare" && is_array($it)) { $ids[] = substr(hash('sha256', implode('|', [$dk, $lv, (string)($it['lag'] ?? ''), (string)($it['from'] ?? ''), (string)($it['to'] ?? ''), (float)($it['hrs'] ?? 0), (string)($it['vt'] ?? '')])), 0, 32); }
            if ($action === "sf_unshare" && is_string($it)) { $ids[] = substr(hash('sha256', $dk . '|' . $it), 0, 32); }
        }
        $n = 0; foreach (array_unique($ids) as $id) { $d = $db->prepare("DELETE FROM {$t}_by WHERE id=? AND uid=?"); $d->execute([$id, $u['id']]); $n += $d->rowCount(); }
        shareGc($db); out(['ok' => true, 'n' => $n]);
    }
    case 'np_mine': case 'sf_mine': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $np = $action === "np_mine"; $t = $np ? 'normshare' : 'shiftshare';
        $dk = mb_substr((string)($body['dk'] ?? ''), 0, 199); $lv = mb_substr((string)($body['lv'] ?? ''), 0, 39);
        $w = ($dk !== '' ? ' AND n.dk=?' : '') . ($np && $lv !== '' ? ' AND n.lv=?' : ''); $par = [$u['id']]; if ($dk !== '') $par[] = $dk; if ($np && $lv !== '') $par[] = $lv;
        $q = $db->prepare("SELECT n.*,b.at bat,(SELECT COUNT(*) FROM {$t}_by x WHERE x.id=n.id) c,(SELECT COUNT(*) FROM {$t}_use g WHERE g.id=n.id) us FROM $t n JOIN {$t}_by b ON b.id=n.id AND b.uid=? WHERE 1=1$w ORDER BY n.created LIMIT 300");
        $q->execute($par);
        out(['items' => array_map(function ($r) use ($np) { $o = ['id' => $r['id'], 'at' => (int)($r['bat'] ?: $r['created']), 'n' => (int)$r['c'], 'used' => (int)$r['us']]; if ($np) { $o += ['lag' => $r['lag'], 'from' => $r['d_from'], 'to' => $r['d_to'], 'hrs' => (float)$r['hrs'], 'vt' => $r['vt']]; } else $o['j'] = $r['j']; return $o; }, $q->fetchAll(PDO::FETCH_ASSOC))]);
    }
    case 'share_stats': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $one = function (string $sql, array $p) use ($db) { $q = $db->prepare($sql); $q->execute($p); return (int)fc($q); };
        $uid = (int)$u['id']; $sh = 0; $us = 0; $new = 0; $q = $db->prepare('SELECT at FROM share_seen WHERE uid=?'); $q->execute([$uid]); $seen = (int)fc($q);
        foreach (['normshare', 'shiftshare'] as $t) {
            $sh += $one("SELECT COUNT(*) FROM {$t}_by WHERE uid=?", [$uid]);
            $us += $one("SELECT COUNT(*) FROM {$t}_use g WHERE g.id IN (SELECT id FROM {$t}_by WHERE uid=?)", [$uid]);
            $new += $one("SELECT COUNT(*) FROM {$t}_use g WHERE g.at>? AND g.id IN (SELECT id FROM {$t}_by WHERE uid=?)", [$seen, $uid]);
        }
        $pts = $sh + 3 * $us; $lv = [[0, ''], [1, 'Bidragyder'], [15, 'Hjælper'], [50, 'Kollegahelt']]; $cur = 0; foreach ($lv as $i => $l) if ($pts >= $l[0]) $cur = $i;
        if ($body['mark'] ?? false) $db->prepare('INSERT OR REPLACE INTO share_seen(uid,at) VALUES(?,?)')->execute([$uid, time()]);
        $tq = $db->prepare('SELECT id,at,note,seen FROM trophy_list WHERE uid=? ORDER BY at'); $tq->execute([$uid]); $troph = $tq->fetchAll(PDO::FETCH_ASSOC);
        if ($body['tseen'] ?? false) $db->prepare('UPDATE trophy_list SET seen=1 WHERE uid=?')->execute([$uid]);
        out(['trophies' => $troph, 'shared' => $sh, 'used' => $us, 'new' => $new, 'points' => $pts, 'level' => $cur, 'name' => $lv[$cur][1], 'next' => $lv[$cur + 1][0] ?? null, 'nextName' => $lv[$cur + 1][1] ?? null]);
    }
    case 'cal': {
        $t = (string)($_GET['t'] ?? '');
        /* Ingen IP-grænse her: adressen har 192 bits tilfældighed, og kalendertjenester (fx Google) henter mange brugeres feeds fra samme IP-adresser. */
        if (!preg_match('/^[a-f0-9]{48}$/', $t)) { http_response_code(404); header('Content-Type: text/plain; charset=utf-8'); echo 'Ikke fundet'; exit; }
        $q = $db->prepare('SELECT ics,updated FROM cals WHERE tok=?'); $q->execute([$t]); $row = fr($q);
        if (!$row) { http_response_code(404); header('Content-Type: text/plain; charset=utf-8'); echo 'Ikke fundet'; exit; }
        $c = $row['ics']; $etag = '"' . md5($c) . '"'; $lm = gmdate('D, d M Y H:i:s', (int)$row['updated']) . ' GMT';
        header('ETag: ' . $etag); header('Last-Modified: ' . $lm);
        if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }
        header('Content-Type: text/calendar; charset=utf-8'); header('Cache-Control: private, max-age=60, must-revalidate');
        header('Content-Disposition: inline; filename="vagtlon.ics"'); header('X-Robots-Tag: noindex');
        echo $c; exit;
    }
    case 'cal_info': {
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $q = $db->prepare('SELECT tok FROM cals WHERE uid=?'); $q->execute([$u['id']]); $t = fc($q);
        out(['token' => $t ?: null]);
    }
    case 'cal_set': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $ics = $body['ics'] ?? null;
        if (!is_string($ics) || strlen($ics) > 2_500_000 || !str_starts_with($ics, 'BEGIN:VCALENDAR') || !str_contains($ics, 'END:VCALENDAR')) fail('Ugyldig kalender.', 400);
        limit($db, "cal_set:{$u['id']}", 600, 3600); hit($db, "cal_set:{$u['id']}");
        $q = $db->prepare('SELECT tok FROM cals WHERE uid=?'); $q->execute([$u['id']]); $tok = fc($q);
        if (!$tok && empty($body['enable'])) out(['token' => null]);
        if (!$tok || !empty($body['reset'])) $tok = bin2hex(random_bytes(24));
        $db->prepare('INSERT INTO cals(uid,tok,ics,updated) VALUES(?,?,?,?) ON CONFLICT(uid) DO UPDATE SET tok=excluded.tok,ics=excluded.ics,updated=excluded.updated')->execute([$u['id'], $tok, $ics, time()]);
        out(['token' => $tok]);
    }
    case 'cal_off': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $db->prepare('DELETE FROM cals WHERE uid=?')->execute([$u['id']]);
        out(['ok' => true]);
    }
    case 'hit': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        limit($db, "hit:$ip", 3000, 3600); hit($db, "hit:$ip");
        $page = (string)($body['p'] ?? ''); if (!in_array($page, ['landing', 'app'], true)) fail('Ugyldig side.', 400);
        $day = date('Y-m-d');
        $vid = substr(hash_hmac('sha256', $day . '|' . $ip . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? ''), secret($db)), 0, 16);
        $db->prepare('INSERT OR IGNORE INTO uv(day,page,vid) VALUES(?,?,?)')->execute([$day, $page, $vid]);
        $db->prepare('INSERT INTO pv(day,page,n) VALUES(?,?,1) ON CONFLICT(day,page) DO UPDATE SET n=n+1')->execute([$day, $page]);
        $ref = strtolower((string)($body['ref'] ?? ''));
        if ($ref !== '' && strlen($ref) <= 100 && preg_match('/^[a-z0-9.-]+$/', $ref) && $ref !== strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')))) {
            $db->prepare('INSERT INTO refs(day,host,n) VALUES(?,?,1) ON CONFLICT(day,host) DO UPDATE SET n=n+1')->execute([$day, $ref]);
        }
        out(['ok' => true]);
    }
    case 'admin_stats': {
        adminOnly($db, $cfg); $now = time();
        $cnt = fn(string $sql, array $a = []) => (function () use ($db, $sql, $a) { $q = $db->prepare($sql); $q->execute($a); return (int)fc($q); })();
        $days = []; for ($i = 29; $i >= 0; $i--) $days[] = date('Y-m-d', $now - $i * 86400);
        $signups = array_fill_keys($days, 0);
        foreach ($db->query('SELECT created FROM users')->fetchAll(PDO::FETCH_COLUMN) as $c) { $d = date('Y-m-d', (int)$c); if (isset($signups[$d])) $signups[$d]++; }
        $vis = []; foreach ($days as $d) $vis[$d] = ['landing_pv' => 0, 'landing_uv' => 0, 'app_pv' => 0, 'app_uv' => 0];
        foreach ($db->query('SELECT day,page,n FROM pv WHERE day>=' . $db->quote($days[0]))->fetchAll(PDO::FETCH_ASSOC) as $r) if (isset($vis[$r['day']])) $vis[$r['day']][$r['page'] . '_pv'] = (int)$r['n'];
        foreach ($db->query('SELECT day,page,COUNT(*) c FROM uv WHERE day>=' . $db->quote($days[0]) . ' GROUP BY day,page')->fetchAll(PDO::FETCH_ASSOC) as $r) if (isset($vis[$r['day']])) $vis[$r['day']][$r['page'] . '_uv'] = (int)$r['c'];
        $refs = $db->query('SELECT host,SUM(n) n FROM refs WHERE day>=' . $db->quote($days[0]) . ' GROUP BY host ORDER BY n DESC LIMIT 10')->fetchAll(PDO::FETCH_ASSOC);
        $agg = ['ok' => [], 'region' => [], 'pos' => [], 'kind' => ['fast' => 0, 'vikar' => 0], 'emps' => 0, 'plan' => 0, 'forms' => 0, 'evacs' => 0, 'flags' => 0, 'withEmps' => 0, 'withPlan' => 0, 'bytes' => 0, 'deps' => []];
        $users = [];
        $q = $db->query('SELECT u.id,u.email,u.created,u.last_seen,u.verified,s.data,s.version,s.updated FROM users u LEFT JOIN states s ON s.uid=u.id ORDER BY u.created DESC LIMIT 5000');
        $trSet = []; foreach ($db->query("SELECT id,uid,at,note FROM trophy_list ORDER BY at")->fetchAll(PDO::FETCH_ASSOC) as $t) $trSet[$t['uid']][] = ['id' => (int)$t['id'], 'note' => $t['note']];
        while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
            $emps = 0; $plan = 0; $forms = 0; $evs = 0; $bytes = strlen((string)$r['data']);
            if ($r['data']) {
                $j = json_decode($r['data'], true);
                if (is_array($j)) {
                    $myDeps = [];
                    foreach (($j['emps'] ?? []) as $e) {
                        if (!empty($e['demo'])) continue;
                        $dn = trim((string)($e['hos'] ?? '') . ((!empty($e['hos']) && !empty($e['dep'])) ? ' · ' : '') . (string)($e['dep'] ?? '')); if ($dn !== '') $myDeps[mb_substr($dn, 0, 90)] = 1;
                        $emps++; $ok = (string)($e['ok'] ?? '?'); $agg['ok'][$ok] = ($agg['ok'][$ok] ?? 0) + 1;
                        $rg = (string)($e['region'] ?? '?'); $agg['region'][$rg] = ($agg['region'][$rg] ?? 0) + 1;
                        $ps = $ok . ':' . (string)($e['pos'] ?? '?'); $agg['pos'][$ps] = ($agg['pos'][$ps] ?? 0) + 1;
                        $k = ($e['kind'] ?? 'fast') === 'vikar' ? 'vikar' : 'fast'; $agg['kind'][$k]++;
                        $evs += is_array($e['evacs'] ?? null) ? count($e['evacs']) : 0;
                    }
                    foreach (array_keys($myDeps) as $dn) $agg['deps'][$dn] = ($agg['deps'][$dn] ?? 0) + 1;
                    $plan = is_array($j['plan'] ?? null) ? count($j['plan']) : 0;
                    foreach (($j['shifts'] ?? []) as $l) $forms += is_array($l) ? count($l) : 0;
                    $agg['flags'] += is_array($j['flag'] ?? null) ? count($j['flag']) : 0;
                }
            }
            $agg['emps'] += $emps; $agg['plan'] += $plan; $agg['forms'] += $forms; $agg['evacs'] += $evs; $agg['bytes'] += $bytes;
            if ($emps) $agg['withEmps']++; if ($plan) $agg['withPlan']++;
            $users[] = ['id' => (int)$r['id'], 'verified' => (int)$r['verified'], 'email' => $r['email'], 'created' => (int)$r['created'], 'last_seen' => $r['last_seen'] ? (int)$r['last_seen'] : null, 'emps' => $emps, 'plan' => $plan, 'forms' => $forms, 'evacs' => $evs, 'trophies' => $trSet[$r['id']] ?? [], 'bytes' => $bytes, 'updated' => $r['updated'] ? (int)$r['updated'] : null];
        }
        arsort($agg['ok']); arsort($agg['region']); arsort($agg['pos']); $agg['pos'] = array_slice($agg['pos'], 0, 12, true); arsort($agg['deps']); $agg['deps'] = array_slice($agg['deps'], 0, 15, true);
        out([
            'now' => $now,
            'totals' => ['users' => $cnt('SELECT COUNT(*) FROM users'), 'unverified' => $cnt('SELECT COUNT(*) FROM users WHERE verified=0'), 'normshare' => $cnt('SELECT COUNT(*) FROM normshare'), 'shiftshare' => $cnt('SELECT COUNT(*) FROM shiftshare'), 'new7' => $cnt('SELECT COUNT(*) FROM users WHERE created>?', [$now - 7 * 86400]), 'new30' => $cnt('SELECT COUNT(*) FROM users WHERE created>?', [$now - 30 * 86400]),
                'dau' => $cnt('SELECT COUNT(*) FROM users WHERE last_seen>?', [$now - 86400]), 'wau' => $cnt('SELECT COUNT(*) FROM users WHERE last_seen>?', [$now - 7 * 86400]), 'mau' => $cnt('SELECT COUNT(*) FROM users WHERE last_seen>?', [$now - 30 * 86400]),
                'dbBytes' => (int)@filesize(($cfg['data_dir'] ?? (__DIR__ . '/data')) . '/app.sqlite')],
            'days' => $days, 'signups' => array_values($signups), 'visits' => array_values($vis), 'refs' => $refs, 'agg' => $agg, 'users' => $users,
        ]);
    }
    case 'admin_delete': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $me = adminOnly($db, $cfg); $id = (int)($body['id'] ?? 0);
        if ($id === (int)$me['id']) fail('Du kan ikke slette din egen konto her.', 400);
        $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]); shareGc($db); out(['ok' => true]);
    }
    case 'admin_trophy': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg); $id = (int)($body['id'] ?? 0); $note = mb_substr(trim((string)($body['note'] ?? '')), 0, 300);
        if (!empty($body['del'])) { $db->prepare('DELETE FROM trophy_list WHERE id=?')->execute([(int)$body['del']]); out(['ok' => true]); }
        $q = $db->prepare('SELECT COUNT(*) FROM users WHERE id=?'); $q->execute([$id]); if (!(int)fc($q)) fail('Brugeren findes ikke.', 404);
        $db->prepare('INSERT INTO trophy_list(uid,at,note) VALUES(?,?,?)')->execute([$id, time(), $note]);
        out(['ok' => true, 'tid' => (int)$db->lastInsertId()]);
    }
    case 'admin_shares': {
        adminOnly($db, $cfg);
        $q = $db->query('SELECT s.id,s.dk,s.j,s.created,(SELECT COUNT(*) FROM shiftshare_by b WHERE b.id=s.id) c FROM shiftshare s ORDER BY s.dk,s.created LIMIT 2000');
        out(['items' => array_map(fn($r) => ['id' => $r['id'], 'dk' => $r['dk'], 'j' => $r['j'], 't' => (int)$r['created'], 'n' => (int)$r['c']], $q->fetchAll(PDO::FETCH_ASSOC))]);
    }
    case 'admin_share_del': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg);
        $ids = is_array($body['ids'] ?? null) ? array_slice($body['ids'], 0, 2000) : [];
        $n = 0;
        foreach ($ids as $id) {
            if (!is_string($id) || !preg_match('/^[a-f0-9]{32}$/', $id)) continue;
            $db->prepare('DELETE FROM shiftshare_by WHERE id=?')->execute([$id]);
            $d = $db->prepare('DELETE FROM shiftshare WHERE id=?'); $d->execute([$id]); $n += $d->rowCount();
        }
        out(['ok' => true, 'n' => $n]);
    }
    case 'admin_notify': {
        $u = adminOnly($db, $cfg); $k = 'notify_signup:' . strtolower($u['email']);
        if ($isPost) {
            $on = !empty($body['on']);
            if ($on) $db->prepare('INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)')->execute([$k, '1']);
            else $db->prepare('DELETE FROM meta WHERE k=?')->execute([$k]);
            out(['ok' => true, 'on' => $on]);
        }
        $q = $db->prepare('SELECT v FROM meta WHERE k=?'); $q->execute([$k]);
        out(['on' => fc($q) === '1', 'to' => $u['email']]);
    }
    case 'admin_verify': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg); $db->prepare('UPDATE users SET verified=1 WHERE id=?')->execute([(int)($body['id'] ?? 0)]); out(['ok' => true]);
    }
    case 'tk_new': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Log ind for at sende en henvendelse.', 401);
        limit($db, "tk:{$u['id']}", 8, 3600); hit($db, "tk:{$u['id']}");
        $k = (string)($body['k'] ?? ''); if (!in_array($k, TK_KINDS, true)) $k = 'fejl';
        $m = trim((string)($body['m'] ?? '')); if (mb_strlen($m) < 5) fail('Skriv et par ord om, hvad det handler om.'); $m = mb_substr($m, 0, 3000);
        $ctx = mb_substr((string)($body['ctx'] ?? ''), 0, 2500);
        $em = !empty($body['em']) ? (string)$u['email'] : '';
        $al = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do { $id = ''; for ($i = 0; $i < 8; $i++) $id .= $al[random_int(0, 31)]; } while (tkGet($db, $id));
        $t = tkNow();
        $db->prepare('INSERT INTO tickets(id,uid,kind,msg,status,created,updated,adm_upd,ctx,email,thread) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([$id, $u['id'], $k, $m, 'ny', $t, $t, '', $ctx, $em, '[]']);
        tkNotifyAdmin($cfg, 'Ny henvendelse ' . $id, "Type: $k\n\n" . mb_substr($m, 0, 600) . "\n\nSvar i appen under Postkasse.");
        out(['id' => $id]);
    }
    case 'tk_mine': {
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $q = $db->prepare('SELECT * FROM tickets WHERE uid=? ORDER BY updated DESC LIMIT 100'); $q->execute([$u['id']]);
        out(['items' => array_map(fn($r) => tkOut($r, false, (int)$u['id']), $q->fetchAll(PDO::FETCH_ASSOC))]);
    }
    case 'tk_reply': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        limit($db, "tkr:{$u['id']}", 30, 3600); hit($db, "tkr:{$u['id']}");
        $r = tkGet($db, (string)($body['id'] ?? '')); if (!$r || (int)$r['uid'] !== (int)$u['id']) fail('Henvendelsen findes ikke.', 404);
        $th = json_decode((string)$r['thread'], true); if (!is_array($th)) $th = [];
        if (count($th) >= 60) fail('Der er for mange beskeder i denne henvendelse. Opret en ny.', 400);
        $m = tkMsg($body); $t = tkNow(); $th[] = ['w' => 'u', 't' => $t, 'm' => $m];
        $db->prepare("UPDATE tickets SET thread=?, status='ny', updated=? WHERE id=?")->execute([json_encode($th, JSON_UNESCAPED_UNICODE), $t, $r['id']]);
        tkNotifyAdmin($cfg, 'Nyt svar på henvendelse ' . $r['id'], mb_substr($m, 0, 600) . "\n\nSvar i appen under Postkasse.");
        out(['ok' => true]);
    }
    case 'tk_del': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $db->prepare('DELETE FROM tk_img WHERE tid IN (SELECT id FROM tickets WHERE id=? AND uid=?)')->execute([(string)($body['id'] ?? ''), $u['id']]);
        $db->prepare('DELETE FROM tickets WHERE id=? AND uid=?')->execute([(string)($body['id'] ?? ''), $u['id']]); out(['ok' => true]);
    }
    case 'tk_admin': {
        $me = adminOnly($db, $cfg);
        $q = $db->query('SELECT * FROM tickets ORDER BY updated DESC LIMIT 500');
        out(['items' => array_map(fn($r) => tkOut($r, true, (int)$me['id']), $q->fetchAll(PDO::FETCH_ASSOC))]);
    }
    case 'tk_areply': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg);
        $r = tkGet($db, (string)($body['id'] ?? '')); if (!$r) fail('Henvendelsen findes ikke.', 404);
        $th = json_decode((string)$r['thread'], true); if (!is_array($th)) $th = [];
        $m = tkMsg($body); $t = tkNow();
        $im = []; foreach ((array)($body['im'] ?? []) as $x) { $x = (string)$x; if (count($im) < 4 && preg_match('/^[A-Za-z0-9]{12}$/', $x)) { $c = $db->prepare('SELECT 1 FROM tk_img WHERE id=? AND tid=?'); $c->execute([$x, $r['id']]); if (fc($c)) $im[] = $x; } }
        $en = ['w' => 'a', 't' => $t, 'm' => $m]; if ($im) $en['i'] = $im; $th[] = $en;
        $st = (string)($body['st'] ?? ''); if (!in_array($st, TK_STATUS, true)) $st = (string)$r['status'];
        $db->prepare('UPDATE tickets SET thread=?, status=?, updated=?, adm_upd=? WHERE id=?')->execute([json_encode($th, JSON_UNESCAPED_UNICODE), $st, $t, $t, $r['id']]);
        if ($r['email'] !== '') mailTo($cfg, (string)$r['email'], 'Svar på din henvendelse ' . $r['id'], $m . ($im ? "\n\n(Svaret har " . count($im) . ' billede' . (count($im) > 1 ? 'r' : '') . " med i appen.)" : '') . "\n\n---\nDu kan også læse og svare i appen under Opsætning, Kontakt.");
        out(['ok' => true]);
    }
    case 'tk_set': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg);
        $st = (string)($body['st'] ?? ''); if (!in_array($st, TK_STATUS, true)) fail('Ukendt status.');
        $t = tkNow();
        $db->prepare('UPDATE tickets SET status=?, updated=?, adm_upd=? WHERE id=?')->execute([$st, $t, $t, (string)($body['id'] ?? '')]); out(['ok' => true]);
    }
    case 'tk_adel': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg);
        $db->prepare('DELETE FROM tk_img WHERE tid=?')->execute([(string)($body['id'] ?? '')]);
        $db->prepare('DELETE FROM tickets WHERE id=?')->execute([(string)($body['id'] ?? '')]); out(['ok' => true]);
    }
    case 'tk_aimg': {
        if (!$isPost) fail('Metode ikke tilladt.', 405);
        adminOnly($db, $cfg);
        $tid = (string)($body['id'] ?? ''); if (!tkGet($db, $tid)) fail('Henvendelsen findes ikke.', 404);
        $d = (string)($body['d'] ?? '');
        if (!preg_match('#^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$#', $d, $mm)) fail('Kun billeder (jpg, png eller webp).');
        $bin = base64_decode($mm[2], true); if ($bin === false || strlen($bin) > 600000) fail('Billedet er for stort. Brug højst ca. 600 kB.');
        if (function_exists('getimagesizefromstring') && !@getimagesizefromstring($bin)) fail('Filen er ikke et gyldigt billede.');
        $n = $db->prepare('SELECT COUNT(*) FROM tk_img WHERE tid=?'); $n->execute([$tid]); if ((int)fc($n) >= 12) fail('Der er allerede 12 billeder på denne henvendelse.');
        $al = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        do { $iid = ''; for ($i = 0; $i < 12; $i++) $iid .= $al[random_int(0, strlen($al) - 1)]; $c = $db->prepare('SELECT 1 FROM tk_img WHERE id=?'); $c->execute([$iid]); } while (fc($c));
        $db->prepare('INSERT INTO tk_img(id,tid,mime,data,created) VALUES(?,?,?,?,?)')->execute([$iid, $tid, 'image/' . $mm[1], $bin, tkNow()]);
        out(['iid' => $iid]);
    }
    case 'tk_img': {
        $u = authUser($db); if (!$u) fail('Du er ikke logget ind.', 401);
        $q = $db->prepare('SELECT i.mime AS mime, i.data AS data, t.uid AS uid FROM tk_img i JOIN tickets t ON t.id=i.tid WHERE i.id=?'); $q->execute([(string)($_GET['id'] ?? '')]); $r = fr($q);
        if (!$r || ((int)$r['uid'] !== (int)$u['id'] && !isAdmin($cfg, $u['email']))) fail('Billedet findes ikke.', 404);
        $data = is_resource($r['data']) ? stream_get_contents($r['data']) : (string)$r['data'];
        http_response_code(200); header('Content-Type: ' . $r['mime']); header('Cache-Control: private, max-age=86400'); header('X-Content-Type-Options: nosniff'); echo $data; exit;
    }
    default: fail('Ukendt handling.', 404);
}
