#!/bin/bash
# Opdaterer Vagtløn fra pakken på GitHub (grenen "live"). Din .env og dine data (appdata/) røres ikke.
#   ./opdater.sh          opdater nu (også hvis versionen er den samme)
#   ./opdater.sh --auto   kør stille; gør kun noget, hvis der er en ny udgivet version (bruges af cron)
# Før hver opdatering tages en sikkerhedskopi. Hvis serveren ikke svarer bagefter, rulles den tilbage automatisk.
set -uo pipefail
ROOT="${VP_HOME:-/opt/vagtplan}"
cd "$ROOT"
AUTO=0; [ "${1:-}" = "--auto" ] && { AUTO=1; shift; }
BASE="${1:-$(cat pkgbase 2>/dev/null || echo https://raw.githubusercontent.com/ALangeland/Vagtplan/live)}"
log() { echo "$(date '+%F %T') $*"; }
exec 9>"$ROOT/.update.lock"; flock -n 9 || { log "opdatering kører allerede"; exit 0; }
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
curl -fsSL -m 30 "$BASE/VERSION" -o "$tmp/VERSION" || { [ $AUTO = 1 ] && exit 0; log "Kunne ikke hente $BASE/VERSION"; exit 1; }
NEW=$(head -1 "$tmp/VERSION" | tr -d '[:space:]'); SHA=$(sed -n 2p "$tmp/VERSION" | tr -d '[:space:]')
CUR=$(cat installed 2>/dev/null || true)
[ $AUTO = 1 ] && [ "$NEW" = "$CUR" ] && exit 0
[ $AUTO = 1 ] && [ "$NEW" = "$(cat failed 2>/dev/null)" ] && exit 0   # prøv ikke den samme dårlige version igen og igen
[ -n "$NEW" ] && [ ${#SHA} = 64 ] || { log "VERSION-filen ser forkert ud. Afbryder."; exit 1; }
curl -fsSL -m 120 "$BASE/vagtplan-php-pakke.zip" -o "$tmp/p.zip" || { log "Kunne ikke hente pakken"; exit 1; }
[ "$(sha256sum "$tmp/p.zip" | cut -d' ' -f1)" = "$SHA" ] || { log "Pakkens kontrolsum passer ikke. Afbryder."; exit 1; }
unzip -q "$tmp/p.zip" -d "$tmp/p"
[ -f "$tmp/p/webroot/app.html" ] && [ -f "$tmp/p/webroot/api/index.php" ] || { log "Pakken ser forkert ud. Afbryder."; exit 1; }
echo "$BASE" > pkgbase
mkdir -p webroot appdata
# 1. sikkerhedskopi (databasen) + gammel version gemmes til tilbagerulning
[ -f appdata/app.sqlite ] && ./vagtplan backup >/dev/null 2>&1 || true
rm -rf webroot.prev; cp -a webroot webroot.prev
# 2. læg ny version ind
rsync -a --delete "$tmp/p/webroot/" webroot/
CFS=$(cksum < Caddyfile 2>/dev/null || echo 0)
for f in Caddyfile docker-compose.yml opdater.sh vagtplan duckdns.sh env.sample; do [ -f "$tmp/p/server/$f" ] && cp -f "$tmp/p/server/$f" "./$f.new" && mv -f "./$f.new" "./$f"; done
chmod +x opdater.sh vagtplan duckdns.sh
[ "$ROOT" = /opt/vagtplan ] && ln -sf /opt/vagtplan/vagtplan /usr/local/bin/vagtplan
touch .env; chmod 600 .env
grep -E '^[A-Z_]+=' env.sample | while IFS= read -r l; do k="${l%%=*}"; grep -q "^$k=" .env || echo "$l" >> .env; done
docker compose pull -q 2>/dev/null || true
docker compose up -d >/dev/null 2>&1 || true
[ "$CFS" != "$(cksum < Caddyfile 2>/dev/null || echo 0)" ] && docker compose restart web >/dev/null 2>&1 || true
# 3. sundhedstjek: databasen skal kunne åbnes af den nye kode, og siden skal svare
DOM=$(grep -m1 '^VP_DOMAIN=' .env | cut -d= -f2- | cut -d, -f1 | tr -d ' "' | sed 's#^https\?://##')
health() {
  docker compose exec -T web php /app/public/api/index.php users >/dev/null 2>&1 || return 1
  curl -fsSk -m 10 -o /dev/null --resolve "$DOM:443:127.0.0.1" "https://$DOM/api/?a=me" || return 1
}
ok=0
for i in 1 2 3 4 5 6 7 8 9 10; do health && { ok=1; break; }; sleep 5; done
if [ $ok = 1 ]; then echo "$NEW" > installed; rm -f failed; log "Opdateret til version $NEW."; exit 0; fi
echo "$NEW" > failed; log "Sundhedstjekket fejlede. Ruller tilbage til den forrige version."
rsync -a --delete webroot.prev/ webroot/; docker compose up -d >/dev/null 2>&1 || true
exit 1
