#!/bin/bash
# Holder dit gratis underdomæne (DuckDNS) pegende på serverens adresse. Kører hvert 5. minut. Gør intet uden duckdns.env.
cd /opt/vagtplan
[ -f duckdns.env ] || exit 0
. ./duckdns.env
[ -n "${DUCKDNS_SUBDOMAIN:-}" ] && [ -n "${DUCKDNS_TOKEN:-}" ] || exit 0
curl -fsS -m 20 "https://www.duckdns.org/update?domains=${DUCKDNS_SUBDOMAIN}&token=${DUCKDNS_TOKEN}&ip=" -o /dev/null || logger -t vagtplan "DuckDNS-opdatering fejlede"
