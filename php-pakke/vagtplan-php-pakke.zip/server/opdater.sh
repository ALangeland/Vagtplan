#!/bin/bash
# Henter den nyeste Vagtplan-pakke og opdaterer serveren. Din .env og dine data (appdata/) røres ikke.
set -euo pipefail
cd /opt/vagtplan
URL="${1:-$(cat pkgurl 2>/dev/null || true)}"
[ -n "$URL" ] || { echo "Mangler adresse til pakken. Brug: ./opdater.sh https://.../vagtplan-php-pakke.zip"; exit 1; }
echo "$URL" > pkgurl
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
curl -fsSL "$URL" -o "$tmp/p.zip"
unzip -q "$tmp/p.zip" -d "$tmp/p"
[ -f "$tmp/p/webroot/app.html" ] || { echo "Pakken ser forkert ud. Afbryder."; exit 1; }
mkdir -p webroot appdata
rsync -a --delete "$tmp/p/webroot/" webroot/
for f in Caddyfile docker-compose.yml opdater.sh vagtplan duckdns.sh env.sample; do cp -f "$tmp/p/server/$f" "./$f"; done
chmod +x opdater.sh vagtplan duckdns.sh
ln -sf /opt/vagtplan/vagtplan /usr/local/bin/vagtplan
# Hold .env i takt med nye indstillinger uden at overskrive dine: tilføj manglende nøgler fra env.sample
touch .env; chmod 600 .env
grep -E '^[A-Z_]+=' env.sample | while IFS= read -r l; do k="${l%%=*}"; grep -q "^$k=" .env || echo "$l" >> .env; done
docker compose pull -q
docker compose up -d
echo "Opdateret $(date '+%Y-%m-%d %H:%M')."
