<?php
/* Kopiér denne fil til config.php og ret værdierne. (På en server med Docker bruges miljøvariabler i stedet, se server/.) */
return [
    'app_name'          => 'Vagtplan',
    'base_url'          => 'https://dit-domaene.dk',     // uden skråstreg til sidst; bruges i links i e-mails
    'mail_from'         => 'noreply@dit-domaene.dk',     // en adresse på dit domæne (eller den, din mailtjeneste har godkendt)
    'admin_emails'      => ['din@email.dk'],          // konti med disse e-mails kan åbne admin.html
    'registration_open' => true,                         // sæt til false for at lukke for nye brugere
    'require_verified'  => true,                         // nye konti skal bekræfte deres e-mail, før de kan logge ind
    // Privatlivssiden: den dataansvarlige. Vises på privatliv.html. Lad stå tomme, så vises en pladsholder.
    'controller'        => '',                           // fx 'Navn Navnesen, Gade 1, 8000 By'
    'contact_email'     => '',                           // kontakt-e-mail til brugere
    // Mail. Uden smtp_host bruges PHP's mail(), som de fleste webhoteller har. På en VPS skal du bruge SMTP.
    // 'smtp_host'      => 'smtp-relay.brevo.com',
    // 'smtp_port'      => 587,
    // 'smtp_secure'    => 'tls',                        // 'tls' (port 587), 'ssl' (port 465) eller 'none'
    // 'smtp_user'      => '',
    // 'smtp_pass'      => '',
    // Lagring af databasen. Læg den helst UDEN FOR websitets mappe, fx '/home/bruger/vagtplan-data'.
    // 'data_dir'       => '/home/bruger/vagtplan-data',
];
