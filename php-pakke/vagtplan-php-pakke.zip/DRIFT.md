# Drift af Vagtplan-serveren

Alle kommandoer køres på serveren (Hetzners *Console* eller SSH). Skriv `vagtplan` uden noget efter for en oversigt.

## Hverdag
| Kommando | Hvad den gør |
|---|---|
| `vagtplan status` | Viser om serveren kører, hvor meget plads der er, og de seneste backups |
| `vagtplan brugere` | Viser alle konti og om de er bekræftet |
| `vagtplan bekraeft bruger@mail.dk` | Bekræfter en konto manuelt |
| `vagtplan adgangskode bruger@mail.dk` | Giver en midlertidig adgangskode |
| `vagtplan log` | Følger serverens log. Afslut med Ctrl+C |
| `vagtplan genstart` | Genstarter efter en ændring i `/opt/vagtplan/.env` |
| `vagtplan opdater` | Henter og installerer den nyeste version af Vagtplan |

Administrationssiden `/admin.html` viser brugere, besøg, overenskomster, afdelinger og henvendelser fra brugerne.

## Opdatering
Du får en ny pakke (`vagtplan-php-pakke.zip`) fra mig. Hvis den er lagt på samme adresse som sidst, nøjes du med `vagtplan opdater`. Dine indstillinger (`.env`) og data (`appdata/`) røres ikke. Ellers kan du give adressen med: `/opt/vagtplan/opdater.sh https://adresse/vagtplan-php-pakke.zip`.

## Sikkerhedskopi og gendannelse
- Hver nat kl. 03.15 laves en komprimeret kopi af databasen i `/opt/vagtplan/appdata/backups/`. De seneste 14 gemmes.
- Kopierne ligger på selve serveren. Hent jævnligt en til din egen computer, eller slå Hetzners backups til (20 % oven i serverprisen). Så overlever du også, hvis serveren selv går tabt.
- **Gendan:**
  ```
  cd /opt/vagtplan
  docker compose stop
  gunzip -c appdata/backups/app-ÅÅÅÅMMDD-TTMMSS.sqlite.gz > appdata/app.sqlite
  rm -f appdata/app.sqlite-wal appdata/app.sqlite-shm
  docker compose start
  ```

## Vokser du?
- Serveren kan opgraderes i Hetzners konsol (*Rescale*). Det giver mere kraft på få minutter. Databasen er kun én fil, og hver bruger fylder én række, så de første mange tusinde brugere kan ligge på samme server.
- Mailtjenesten Brevo er gratis op til 300 mails om dagen. Over det koster den fra ca. 9 $ om måneden.
- Mærker du, at mange skriver samtidigt (flere hundrede ad gangen), er næste skridt at flytte databasen fra SQLite til PostgreSQL. Det er en afgrænset ændring i `api/index.php`.

## Hvad serveren gemmer
- Konti: e-mail og adgangskode (kun som sikker hash).
- Hver brugers samlede data som én post. Administratoren ser kun e-mail og tal.
- Delte normperioder og vagtformer: anonymt, uden kobling til en bruger. De fjernes, når den sidste der delte dem, sletter sin konto.
- Besøgstal pr. dag uden cookies og uden IP-adresser.
- Brugere kan selv hente alle deres data og slette deres konto i appen.

## Sikkerhed
- Port 22 (SSH), 80 og 443 er åbne. Resten er lukket (ufw), og fail2ban blokerer gentagne loginforsøg på SSH.
- Ubuntu installerer sikkerhedsopdateringer automatisk. Kør af og til `apt update && apt upgrade -y` og genstart serveren.
- `/opt/vagtplan/.env` indeholder dine mail-oplysninger. Del den aldrig.
