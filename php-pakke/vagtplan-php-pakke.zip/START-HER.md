# Vagtplan – kom i gang med beta på din egen server

Denne pakke indeholder alt til at køre Vagtplan med login, synkronisering mellem enheder, kalenderabonnement, deling mellem kolleger og administration. Den bruger kun PHP og en lille database-fil (SQLite). Der er ingen Firebase i den.

Du har to veje:

| | A. Server (anbefalet til beta) | B. Webhotel med PHP |
|---|---|---|
| Hvad | En lille server hos Hetzner (Tyskland/Finland), sat op automatisk | Et almindeligt dansk webhotel |
| Adresse fra første minut | Ja, gratis underdomæne, fx `vagtplan-beta.duckdns.org` | Det afhænger af udbyderen. Mange giver en midlertidig adresse |
| Pris | ca. 5–7 € pr. måned | fra få kroner til ca. 100 kr. pr. måned |
| Skalerer | Ja, du kan opgradere serveren med et klik | Nej, du skifter udbyder, når du vokser fra det |
| Din indsats | ca. 30 minutter første gang, derefter næsten ingenting | ca. 15 minutter |

Denne guide går igennem vej A. Vej B står til sidst.

---

## Vej A – Server hos Hetzner

### Det skal du bruge
- En e-mailadresse til administrator-kontoen (den, du selv opretter dig med i appen).
- En konto hos [DuckDNS](https://www.duckdns.org) (gratis, du logger ind med Google, GitHub eller lignende).
- En konto hos [Hetzner Cloud](https://www.hetzner.com/cloud) (kort kræves, og Hetzner kan bede om at verificere dig).
- En Gmail-konto med 2-trinsbekræftelse, som sender mails til dine brugere i betaperioden.

### Trin 1. Reservér din adresse (2 minutter)
1. Gå til duckdns.org og log ind.
2. Skriv et navn i feltet *sub domain*, fx `vagtplan-beta`, og tryk *add domain*. Din adresse bliver `vagtplan-beta.duckdns.org`.
3. Kopiér dit **token** øverst på siden. Det skal bruges om lidt.

### Trin 2. Gør klar til at sende mails (5 minutter)
Appen sender en mail, når nogen opretter en konto (bekræftelse), glemmer deres kode eller får svar på en henvendelse.

I betaperioden er det nemmest at bruge din Gmail:
1. Gå til [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords). Det kræver, at 2-trinsbekræftelse er slået til på din Google-konto.
2. Opret en app-adgangskode med navnet `Vagtplan`. Google viser en kode på 16 tegn. Skriv den uden mellemrum.

Mails vil så vise din Gmail-adresse som afsender. Du kan skifte til en afsender på dit eget domæne, så snart du har et (se *Eget domæne* nedenfor).

### Trin 3. Ret filen `cloud-init.yaml` (5 minutter)
Åbn `cloud-init.yaml` i et tekstprogram (Notesblok, TextEdit, VS Code). Ret kun de linjer, der er markeret `<<< RET`:

| Felt | Hvad du skriver |
|---|---|
| `DUCKDNS_SUBDOMAIN` | Navnet fra trin 1, uden `.duckdns.org` |
| `DUCKDNS_TOKEN` | Dit token fra trin 1 |
| `VP_DOMAIN` | Hele adressen, fx `vagtplan-beta.duckdns.org` |
| `VP_BASE_URL` | Samme adresse med `https://` foran |
| `VP_ADMIN_EMAILS` | Din e-mail. Kontoen med den e-mail får adgang til `/admin.html` |
| `VP_MAIL_FROM` og `VP_SMTP_USER` | Din Gmail-adresse |
| `VP_SMTP_PASS` | App-adgangskoden fra trin 2 |

Lad `VP_CONTROLLER` og `VP_CONTACT_EMAIL` være tomme foreløbigt. De udfylder du, før du inviterer andre (se *Før du åbner for andre*).

### Trin 4. Opret serveren (5 minutter)
1. Log ind på [console.hetzner.cloud](https://console.hetzner.cloud) og opret et projekt.
2. Tryk *Add server* (Tilføj server) og vælg:
   - **Location:** Falkenstein, Nürnberg eller Helsinki. Alle ligger i EU.
   - **Image:** Ubuntu 24.04
   - **Type:** *Shared vCPU* → den billigste x86-model (CX23). Den er rigeligt til beta.
   - **Networking:** behold *Public IPv4* slået til. Uden den kan DuckDNS ikke pege på serveren.
   - **SSH keys:** valgfrit. Du behøver ikke at logge ind på serveren for at bruge appen.
   - **Backups:** slå dem gerne til (koster 20 % ekstra). Det er den nemmeste ekstra sikkerhed.
   - **Cloud config:** indsæt hele indholdet af den rettede `cloud-init.yaml`.
3. Tryk *Create & buy now*.

### Trin 5. Vent og åbn adressen (ca. 4 minutter)
Serveren installerer sig selv. Når der er gået fire-fem minutter, åbner du `https://vagtplan-beta.duckdns.org`.

Du ser forsiden. Prøv:
1. Tryk på *Log ind* → *Opret konto*, og brug den e-mail, du skrev i `VP_ADMIN_EMAILS`.
2. Åbn mailen (tjek også spam), tryk på linket, og log ind.
3. Åbn `/admin.html` på samme adresse. Du ser brugere, besøg og henvendelser.

Hvis forsiden ikke kommer: se *Hvis noget går galt* nedenfor.

### Trin 6. Test, før du inviterer andre
- Opret en konto nummer to med en anden e-mail, og tjek at bekræftelsesmailen kommer frem.
- Slå kalenderabonnement til under *Opsætning* og tilføj adressen i din kalender.
- Del en normperiode fra den ene konto, og hent den på den anden.
- Åbn appen på telefonen og læg den på hjemmeskærmen.

---

## Før du åbner for andre
1. **Privatlivssiden:** Udfyld dit navn og din adresse som dataansvarlig, og en kontakt-e-mail. Det gør du i filen `/opt/vagtplan/.env` på serveren (`VP_CONTROLLER` og `VP_CONTACT_EMAIL`), og så kører du `vagtplan genstart`. Teksten dukker op på `/privatliv.html`. Kontakt-e-mailen bliver offentlig, så vælg en adresse, du er glad for at vise.
2. **Databehandleraftale:** Hetzner er din databehandler. Acceptér deres databehandleraftale i Hetzners konsol. Det er din opgave, ikke appens.
3. **Overenskomsterne:** Appen viser en status pr. overenskomst (Afstemt, Gennemgået eller Grundmodel). Fortæl dine testere, at tallene er vejledende, og at de skal tjekke mod deres lønseddel.
4. **Backup:** Serveren tager en sikkerhedskopi hver nat kl. 03.15 og gemmer de seneste 14. Se *Drift* i `DRIFT.md`, og slå gerne Hetzners egne backups til.

## Eget domæne (når du har købt dit `.dk`)
1. Hos domæneudbyderen: opret en **A-record** for dit domæne (og gerne `www`) med serverens IPv4-adresse (står i Hetzners konsol).
2. Log ind på serveren (SSH, eller *Console* i Hetzners konsol) og ret `/opt/vagtplan/.env`:
   - `VP_DOMAIN=dit-domaene.dk, vagtplan-beta.duckdns.org` (den gamle adresse beholdes, så eksisterende kalenderabonnementer virker)
   - `VP_BASE_URL=https://dit-domaene.dk`
3. Kør `vagtplan genstart`. Serveren henter selv certifikat til det nye domæne.
4. Mails: Opret en gratis konto hos [Brevo](https://www.brevo.com), godkend dit domæne dér (de viser, hvilke DNS-poster du skal oprette), og ret `VP_SMTP_*` og `VP_MAIL_FROM=noreply@dit-domaene.dk`. Så kommer mails fra din egen adresse og lander sjældnere i spam.

Browseren gemmer data pr. adresse. Brugere, der har lagt appen på hjemmeskærmen på den gamle adresse, skal åbne den nye og logge ind igen. Deres data ligger på serveren og er uberørte.

## Hvis noget går galt
| Problem | Løsning |
|---|---|
| Siden svarer ikke efter 10 minutter | Tjek at DuckDNS-tokenet og navnet er rigtige. Log ind på serveren og skriv `vagtplan status` og `vagtplan log` |
| Browseren advarer om certifikat | Vent 5 minutter. Serveren har brug for, at adressen peger på den, før den kan hente certifikat |
| Bekræftelsesmailen kommer ikke | Tjek spam. Kør `vagtplan brugere` for at se, hvem der er ubekræftet, og `vagtplan bekraeft bruger@mail.dk` for at bekræfte manuelt. Eller tryk *Bekræft* ud for brugeren i `/admin.html` |
| En bruger har glemt sin kode, og mailen kommer ikke | `vagtplan adgangskode bruger@mail.dk` giver en midlertidig kode |
| Gmail afviser login | Brug app-adgangskoden uden mellemrum, ikke din almindelige kode |

Log ind på serveren: i Hetzners konsol, åbn serveren og tryk på *Console*-ikonet, eller brug SSH, hvis du har lagt en nøgle ind.

---

## Vej B – Webhotel med PHP
1. Find et webhotel med **PHP 8.1 eller nyere**, **SQLite (pdo_sqlite)**, HTTPS og mail via PHP. Tjek det med en fil `info.php` med indholdet `<?php phpinfo();`, og slet den bagefter.
2. Upload alt i mappen `webroot/` (inkl. skjulte filer som `.htaccess`) til webhotellets rod.
3. Kopiér `api/config.sample.php` til `api/config.php`, og ret `base_url`, `mail_from` og `admin_emails`. Sæt gerne `data_dir` til en mappe **uden for** websitet.
4. Åbn adressen, opret en konto, bekræft via mail, og åbn `/admin.html`.
5. Hvis mail ikke virker via webhotellet, så tilføj `smtp_host`, `smtp_user` og `smtp_pass` i `config.php` (se kommentarerne i filen).

Sikkerhedskopi: kopiér `app.sqlite` fra datamappen. Det er hele databasen.
